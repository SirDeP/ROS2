/* DatabaseManager.hpp
 * Database manager for the IMU data collection system
 *
 * Reviewed by: <x>
 * Changelog:
 * [23-09-2025] Wessel T: Created database manager class for all DB operations
 * [14-10-2025] Wessel T: Updated for IMU data storage functionality
 */
#pragma once

#include <memory>
#include <vector>
#include <string>
#include <pqxx/pqxx>
#include "rclcpp/rclcpp.hpp"

#include "config/ConfigManager.hpp"

namespace assignments::two {

class DatabaseManager {
public:
    explicit DatabaseManager(rclcpp::Logger logger);
    ~DatabaseManager() = default;

    bool connect(const std::string& connection_string);
    virtual bool is_connected() const;

    // Table operations
    virtual void init_database();
    void create_tables();

    // IMU Data operations
    virtual bool store_imu_data(
        double linear_accel_x, double linear_accel_y, double linear_accel_z,
        double angular_vel_x, double angular_vel_y, double angular_vel_z
    );

private:
    rclcpp::Logger logger_;

    std::unique_ptr<pqxx::connection> conn_;
    std::unique_ptr<ConfigManager> config_manager_;
};

} // namespace assignments::two
