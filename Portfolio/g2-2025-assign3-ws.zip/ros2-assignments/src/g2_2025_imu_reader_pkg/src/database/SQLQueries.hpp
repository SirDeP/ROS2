/* SQLQueries.hpp
 * SQL query definitions for the IMU data collection system
 *
 * Reviewed by: <x>
 * Changelog:
 * [23-09-2025] Wessel T: Created initial database state
 * [14-10-2025] Wessel T: Updated for IMU data storage
 */
#pragma once

static const std::string SQL_CREATE_IMU_DATA_TABLE = R"(
    CREATE TABLE IF NOT EXISTS imu_data (
        id SERIAL PRIMARY KEY,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        linear_accel_x REAL NOT NULL,
        linear_accel_y REAL NOT NULL,
        linear_accel_z REAL NOT NULL,
        angular_vel_x REAL NOT NULL,
        angular_vel_y REAL NOT NULL,
        angular_vel_z REAL NOT NULL
    );
)";

static const std::string SQL_INSERT_IMU_DATA = R"(
    INSERT INTO imu_data (
        linear_accel_x, linear_accel_y, linear_accel_z,
        angular_vel_x, angular_vel_y, angular_vel_z
    ) VALUES ($1, $2, $3, $4, $5, $6);
)";
