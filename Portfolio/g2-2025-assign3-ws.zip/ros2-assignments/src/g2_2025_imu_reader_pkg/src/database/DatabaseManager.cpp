#include "DatabaseManager.hpp"

#include <pqxx/pqxx>
#include "rclcpp/rclcpp.hpp"

#include "SQLQueries.hpp"
#include "config/ConfigManager.hpp"

namespace assignments::two {

DatabaseManager::DatabaseManager(rclcpp::Logger logger) : logger_(logger) {
    config_manager_ = std::make_unique<ConfigManager>(logger_);
    init_database();
}

bool DatabaseManager::is_connected() const {
    return conn_ && conn_->is_open();
}

bool DatabaseManager::connect(const std::string& connection_string) {
    try {
        RCLCPP_INFO(logger_, "[DBS] connecting to PostgreSQL database...");

        conn_ = std::make_unique<pqxx::connection>(connection_string);

        if (conn_->is_open()) {
            RCLCPP_INFO(logger_, "[DBS] '%s': successfully connected to database", conn_->dbname());
            return true;
        } else {
            RCLCPP_ERROR(logger_, "[DBS] failed to open database connection");
            return false;
        }

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] sql error: %s", e.what());
        return false;
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] connection error: %s", e.what());
        return false;
    }
}

void DatabaseManager::init_database() {
    if (!config_manager_ || !config_manager_->is_loaded()) {
        RCLCPP_ERROR(logger_, "[DBS] configuration not loaded, cannot initialize database");
        return;
    }

    auto db_config = config_manager_->get_database_config();
    if (!db_config.has_value()) {
        RCLCPP_ERROR(logger_, "[DBS] failed to get database configuration");
        return;
    }

    std::string connection_string = db_config->to_connection_string();

    if (connect(connection_string)) {
        create_tables();
    }
}

void DatabaseManager::create_tables() {
    if (!conn_ || !conn_->is_open()) return;

    try {
        pqxx::work txn(*conn_);

        txn.exec(SQL_CREATE_IMU_DATA_TABLE);

        txn.commit();

        RCLCPP_INFO(logger_, "[DBS] database tables ready");

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] CREATE TABLE failed: %s", e.what());
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] database error: %s", e.what());
    }
}

bool DatabaseManager::store_imu_data(
    double linear_accel_x, double linear_accel_y, double linear_accel_z,
    double angular_vel_x, double angular_vel_y, double angular_vel_z
) {
    if (!is_connected()) {
        RCLCPP_WARN(logger_, "[DBS] not connected to database");
        return false;
    }

    try {
        pqxx::work txn(*conn_);

        txn.exec_params(SQL_INSERT_IMU_DATA,
            linear_accel_x, linear_accel_y, linear_accel_z,
            angular_vel_x, angular_vel_y, angular_vel_z
        );

        txn.commit();

        RCLCPP_DEBUG(logger_, "[DBS] stored IMU data: accel=[%.3f,%.3f,%.3f], angular=[%.3f,%.3f,%.3f]",
            linear_accel_x, linear_accel_y, linear_accel_z,
            angular_vel_x, angular_vel_y, angular_vel_z
        );

        return true;

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] failed to store IMU data: %s", e.what());
        return false;
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] database error: %s", e.what());
        return false;
    }
}

} // namespace assignments::two
