/* ConfigManager.hpp
 * Configuration management for the exam result generator
 * Uses toml++ library to parse TOML configuration files
 *
 * Reviewed by: <x>
 * Changelog:
 * [23-09-2025] Wessel T: Created configuration manager class for TOML config loading
 */
#pragma once

#include <string>
#include <optional>
#include <filesystem>
#include <toml++/toml.h>
#include "rclcpp/rclcpp.hpp"

#include "DatabaseConfig.hpp"

namespace assignments::two {

class ConfigManager {
public:
    explicit ConfigManager(rclcpp::Logger logger);
    ~ConfigManager() = default;

    bool load_config(const std::string& config_file_path);

    std::optional<DatabaseConfig> get_database_config() const;

    bool is_loaded() const;

private:
    rclcpp::Logger logger_;

    std::optional<toml::table> config_;

    bool loaded_ { false };
    std::vector<std::string> default_config_paths_ = {
        "config.toml",
        "./src/config.toml",
        "../config.toml",
        "../../config.toml",
        "../../../config.toml",
        "../../../../config.toml",
        "/etc/ros2_grade_calculator/config.toml"
    };

    std::string find_config_file() const;
    DatabaseConfig parse_database_config(const toml::table& config) const;
};

} // namespace assignments::two
