/* nodes/IMUDatabaseWriter.hpp
 * IMU database writer node for storing IMU sensor data.
 *
 * Receives IMU sensor data from sensor_msgs/msg/Imu messages and stores
 * the data to a database for further processing.
 *
 * Changelog:
 * [13-10-2025] Wessel T: Implement template
 * [14-10-2025] Wessel T: Updated to use sensor_msgs/msg/Imu
 */
#pragma once

#include <memory>
#include <string>
#include <random>
#include <vector>
#include <chrono>

#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/imu.hpp"

#include "database/DatabaseManager.hpp"

namespace assignments::two::imu_database_writer {

class IMUDatabaseWriter : public rclcpp::Node {
public:
    IMUDatabaseWriter(std::unique_ptr<DatabaseManager> db_manager = nullptr);

    void imu_data_callback(const sensor_msgs::msg::Imu::SharedPtr msg);

private:
    rclcpp::Subscription<sensor_msgs::msg::Imu>::SharedPtr imu_subscriber_;

    std::unique_ptr<DatabaseManager> db_manager_;
};

} // namespace assignments::two::imu_database_writer
