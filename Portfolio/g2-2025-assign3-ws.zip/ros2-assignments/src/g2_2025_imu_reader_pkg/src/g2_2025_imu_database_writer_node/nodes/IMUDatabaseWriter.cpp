#include "IMUDatabaseWriter.hpp"

namespace assignments::two::imu_database_writer {

IMUDatabaseWriter::IMUDatabaseWriter(std::unique_ptr<DatabaseManager> db_manager)
    : Node("g2_2025_imu_database_writer_node")
{
    // allow injection of mock database manager for tests
    if (db_manager) {
        db_manager_ = std::move(db_manager);
    } else {
        db_manager_ = std::make_unique<DatabaseManager>(this->get_logger());
    }

    // Create subscriber for IMU data
    imu_subscriber_ = this->create_subscription<sensor_msgs::msg::Imu>(
        "imu_data", 10,
        std::bind(
            &IMUDatabaseWriter::imu_data_callback,
            this,
            std::placeholders::_1
        )
    );

    RCLCPP_INFO(this->get_logger(),
        "imu_database_writer started, ready to receive IMU data"
    );
}

void IMUDatabaseWriter::imu_data_callback(const sensor_msgs::msg::Imu::SharedPtr msg) {
    RCLCPP_DEBUG(this->get_logger(),
        "Received: linear_accel=[%.2f, %.2f, %.2f], angular_vel=[%.2f, %.2f, %.2f]",
        msg->linear_acceleration.x, msg->linear_acceleration.y, msg->linear_acceleration.z,
        msg->angular_velocity.x, msg->angular_velocity.y, msg->angular_velocity.z
    );

    db_manager_->store_imu_data(
        msg->linear_acceleration.x, msg->linear_acceleration.y, msg->linear_acceleration.z,
        msg->angular_velocity.x, msg->angular_velocity.y, msg->angular_velocity.z
    );
}

} // namespace assignments::two::imu_database_writer
