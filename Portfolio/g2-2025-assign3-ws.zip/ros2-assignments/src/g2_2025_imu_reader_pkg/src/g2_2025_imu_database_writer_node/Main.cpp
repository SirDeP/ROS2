/* main.cpp
 * Entry point for the exam result generator node
 *
 * Reviewed by: <x>
 * Changelog:
 * [23-09-2025] Wessel T: Simplified main.cpp to entry point only
 */

#include "rclcpp/rclcpp.hpp"
#include "nodes/IMUDatabaseWriter.hpp"

int main(int argc, char *argv[]) {
    rclcpp::init(argc, argv);

    auto node = std::make_shared<assignments::two::imu_database_writer::IMUDatabaseWriter>();

    rclcpp::spin(node);
    rclcpp::shutdown();

    return 0;
}
