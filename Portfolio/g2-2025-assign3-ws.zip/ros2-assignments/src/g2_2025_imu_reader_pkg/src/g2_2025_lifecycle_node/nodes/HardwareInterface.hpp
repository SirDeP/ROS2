/* nodes/HardwareInterface.hpp
 * Hardware interface implementation for the IMU reader system.
 *
 * Manages the serial communication with the IMU hardware, including initialization,
 * data acquisition, and shutdown procedures.
 *
 * Changelog:
 * [28-10-2025] M.khalaf: Implemented template.
 * [28-10-2025] M.khalaf: Added serial communication support.
 * [30-10-2025] M.khalaf: Added MQTT support.
 * [20-10-2025] M.khalaf: Refactored code for readability.
 * [30-10-2025] M.khalaf: Improved error handling.
 * [31-10-2025] M.khalaf: Fixed serial read and mqtt configurations.
 * [06-11-2025] Wessel T, Vincent W: Clean up code, remove uncessary imports
 */
#pragma once

#include <memory>
#include <thread>
#include <atomic>
#include <string>
#include <nlohmann/json.hpp>
#include <mqtt/client.h>

#include "serialib.h"

#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/imu.hpp"

#include "MQTTParameters.hpp"

namespace assignments::two::g2_2025_lifecycle_node {

class HardwareInterface : public rclcpp::Node {

public:
    HardwareInterface(MQTTParameters mqtt_config);
    ~HardwareInterface();

    bool uart_open_device(const std::string& device_path, int baud_rate);
    bool uart_device_is_open();
    void uart_close_device();

    void uart_start_read();
    void uart_stop_read();

    void mqtt_configure();
    void mqtt_connect();

    void mqtt_start_listen();
    void mqtt_stop_listen();
    void mqtt_close_connection();

    void parse_and_publish_imu_data(const std::string& data);

private:
    rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_publisher_;

    serialib serial_;

    MQTTParameters mqtt_config_;
    std::unique_ptr<mqtt::client> mqtt_client_;

    std::thread uart_read_thread_;
    std::atomic_bool uart_reading_ {false};

    std::thread mqtt_read_thread_;
    std::atomic_bool mqtt_reading_ {false};

    static void mqtt_message_callback(const std::string& topic, const std::string& payload, HardwareInterface* self);
};

}  // namespace assignments::two::g2_2025_lifecycle_node
