/* nodes/LifecycleManager.hpp
 * Lifecycle node implementation for managing the lifecycle of the IMU reader system.
 *
 * Manages the different states of the lifecycle node, including configuration,
 * and hardware interface management.
 *
 * Changelog:
 * [28-10-2025] M.khalaf: Implemented template.
 */
#pragma once

#include "rclcpp/rclcpp.hpp"
#include "rclcpp_lifecycle/lifecycle_node.hpp"
#include "std_msgs/msg/string.hpp"
#include "HardwareInterface.hpp"

#include "MQTTParameters.hpp"

namespace assignments::two::g2_2025_lifecycle_node {

class LifecycleManager : public rclcpp_lifecycle::LifecycleNode {
public:
    LifecycleManager();

    // Hardware interface to interact with the IMU device. Made public for testing purposes
    std::shared_ptr<HardwareInterface> hw_interface;

private:
    std::string device_path_;
    int baudrate_;
    std::string communication_type_;

    MQTTParameters mqtt_config_ {};

    rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_publisher_;

    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
        on_error(const rclcpp_lifecycle::State&);
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
        on_cleanup(const rclcpp_lifecycle::State&);
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
        on_configure(const rclcpp_lifecycle::State&);
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
        on_activate(const rclcpp_lifecycle::State&);
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
        on_deactivate(const rclcpp_lifecycle::State&);
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
        on_shutdown(const rclcpp_lifecycle::State&);
};

}  // namespace assignments::two::g2_2025_lifecycle_node
