#include "HardwareInterface.hpp"

namespace assignments::two::g2_2025_lifecycle_node {

HardwareInterface::HardwareInterface(MQTTParameters mqtt_config)
: Node("HardwareInterface")
, mqtt_config_(mqtt_config)
{
    RCLCPP_INFO(this->get_logger(), "created HardwareInterface node");

    imu_publisher_ = this->create_publisher<sensor_msgs::msg::Imu>("imu_data", 10);
    RCLCPP_INFO(this->get_logger(), "created IMU Publisher on topic 'imu_data'");
}

HardwareInterface::~HardwareInterface() {
    uart_stop_read();

    if (uart_device_is_open()) {
        uart_close_device();
    }

    mqtt_close_connection();
}

void HardwareInterface::parse_and_publish_imu_data(const std::string& data) {
    try {
        auto json_data = nlohmann::json::parse(data);
        auto imu_msg = std::make_shared<sensor_msgs::msg::Imu>();

        imu_msg->header.stamp = this->now();
        imu_msg->header.frame_id = "imu_link";

        // angular velocity
        if (json_data.contains("accel") && json_data["accel"].is_object()) {
            imu_msg->linear_acceleration.x = json_data["accel"].value("x", 0.0);
            imu_msg->linear_acceleration.y = json_data["accel"].value("y", 0.0);
            imu_msg->linear_acceleration.z = json_data["accel"].value("z", 0.0);
        }

        // linear acceleration
        if (json_data.contains("gyro") && json_data["gyro"].is_object()) {
            imu_msg->angular_velocity.x = json_data["gyro"].value("x", 0.0);
            imu_msg->angular_velocity.y = json_data["gyro"].value("y", 0.0);
            imu_msg->angular_velocity.z = json_data["gyro"].value("z", 0.0);
        }

        RCLCPP_INFO(this->get_logger(),
            "Publishing IMU Data - Accel: [%.3f, %.3f, %.3f], Gyro: [%.3f, %.3f, %.3f]",
            imu_msg->linear_acceleration.x, imu_msg->linear_acceleration.y, imu_msg->linear_acceleration.z,
            imu_msg->angular_velocity.x, imu_msg->angular_velocity.y, imu_msg->angular_velocity.z
        );

        imu_publisher_->publish(*imu_msg);
    } catch (const nlohmann::json::exception& e) {
        RCLCPP_ERROR(this->get_logger(), "JSON parsing error: %s", e.what());
    }
}

void HardwareInterface::uart_start_read() {
    if (uart_reading_.load()) {
        return;
    }

    uart_reading_.store(true);

    uart_read_thread_ = std::thread([this]() {
        char buffer[116];
        RCLCPP_INFO(this->get_logger(), "reader thread started");

        while (uart_reading_.load()) {
            int ret = serial_.readString(buffer, '\n', sizeof(buffer), 1000);
            if (ret > 0) {
                RCLCPP_INFO(this->get_logger(), "Received buffer: %s", buffer);
                parse_and_publish_imu_data(buffer);
            }
        }

        RCLCPP_INFO(this->get_logger(), "reader thread exiting");
    });
}

void HardwareInterface::uart_stop_read() {
    if (!uart_reading_.load()) return;
    uart_reading_.store(false);

    if (uart_read_thread_.joinable()) {
        uart_read_thread_.join();
    }
}

bool HardwareInterface::uart_open_device(const std::string& device_path, int baud_rate) {
    char errorOpening = serial_.openDevice(device_path.c_str(), baud_rate);

    if (errorOpening != 1) {
        RCLCPP_ERROR(this->get_logger(), "Error opening serial_ port: %d", errorOpening);
        return false;
    }

    RCLCPP_INFO(this->get_logger(), "serial_ port opened successfully.");
    return true;
}

bool HardwareInterface::uart_device_is_open() {
    return serial_.isDeviceOpen();
}

void HardwareInterface::uart_close_device() {
    serial_.closeDevice();
}

void HardwareInterface::mqtt_message_callback(
    const std::string& topic,
    const std::string& payload,
    HardwareInterface* self
) {
    if (self) {
        RCLCPP_INFO(self->get_logger(), "Message received on topic %s: %s", topic.c_str(), payload.c_str());

        self->parse_and_publish_imu_data(payload);
    }
}

void HardwareInterface::mqtt_configure() {
    try {
        RCLCPP_INFO(this->get_logger(), "Creating MQTT client with server: %s, client_id: %s",
            mqtt_config_.server_address.c_str(), mqtt_config_.client_id.c_str()
        );

        // Create client with basic constructor (no persistence, no create options)
        mqtt_client_ = std::make_unique<mqtt::client>(
            mqtt_config_.server_address,
            mqtt_config_.client_id
        );

        RCLCPP_INFO(this->get_logger(), "MQTT client created successfully");

        mqtt_connect();
    } catch (const std::exception& e) {
        RCLCPP_ERROR(this->get_logger(), "Exception in mqtt_configure: %s", e.what());
        throw;
    }
}

void HardwareInterface::mqtt_start_listen() {
    RCLCPP_INFO(this->get_logger(), "MQTT listener started - consuming messages synchronously");

    // Start a background thread to consume messages
    if (!mqtt_reading_.load()) {
        mqtt_reading_.store(true);
        mqtt_read_thread_ = std::thread([this]() {
            RCLCPP_INFO(this->get_logger(), "MQTT consumer thread started");

            try {
                while (mqtt_reading_.load() && mqtt_client_ && mqtt_client_->is_connected()) {
                    mqtt::const_message_ptr msg;
                    if (mqtt_client_->try_consume_message(&msg)) {
                        mqtt_message_callback(msg->get_topic(), msg->get_payload_str(), this);
                    } else {
                        // No message available, sleep briefly to avoid busy-waiting
                        std::this_thread::sleep_for(std::chrono::milliseconds(100));
                    }
                }
            } catch (const mqtt::exception& exc) {
                RCLCPP_ERROR(this->get_logger(), "MQTT consumer error: %s", exc.what());
            }

            RCLCPP_INFO(this->get_logger(), "MQTT consumer thread exiting");
        });
    }
}

void HardwareInterface::mqtt_connect() {
    if (!mqtt_client_) {
        RCLCPP_ERROR(this->get_logger(), "MQTT client is not initialized");
        return;
    }

    try {
        RCLCPP_INFO(this->get_logger(), "Connecting to MQTT broker...");

        mqtt_client_->connect();
        RCLCPP_INFO(this->get_logger(), "Connected to broker");

        RCLCPP_INFO(this->get_logger(), "Subscribing to topic: %s", mqtt_config_.topic.c_str());
        mqtt_client_->subscribe(mqtt_config_.topic, 1);
        RCLCPP_INFO(this->get_logger(), "Subscribed to topic: %s", mqtt_config_.topic.c_str());
    } catch (const mqtt::exception& exc) {
        RCLCPP_ERROR(this->get_logger(), "MQTT Error: %s", exc.what());
        throw;
    }
}

void HardwareInterface::mqtt_stop_listen() {
    if (mqtt_reading_.load()) {
        mqtt_reading_.store(false);
        if (mqtt_read_thread_.joinable()) {
            mqtt_read_thread_.join();
        }
    }
}

void HardwareInterface::mqtt_close_connection() {
    try {
        mqtt_stop_listen();

        if (mqtt_client_) {
            if (mqtt_client_->is_connected()) {
                mqtt_client_->disconnect();
                RCLCPP_INFO(this->get_logger(), "Disconnected MQTT client");
            }
            mqtt_client_.reset();
        }
    } catch (const mqtt::exception& exc) {
        RCLCPP_ERROR(this->get_logger(), "Error while disconnecting MQTT: %s", exc.what());
    }
}

} // namespace assignments::two::g2_2025_lifecycle_node
