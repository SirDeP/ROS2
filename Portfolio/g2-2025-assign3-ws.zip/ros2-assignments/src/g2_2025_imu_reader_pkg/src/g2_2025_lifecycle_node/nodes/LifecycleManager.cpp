#include "LifecycleManager.hpp"
#include "HardwareInterface.hpp"

namespace assignments::two::g2_2025_lifecycle_node {

LifecycleManager::LifecycleManager() : rclcpp_lifecycle::LifecycleNode("LifecycleManager") {
    mqtt_config_.server_address =
        this->declare_parameter<std::string>("mqtt_server_address", "tcp://localhost:1883");

    mqtt_config_.client_id =
        this->declare_parameter<std::string>("mqtt_client_id", "cpp_mqtt-client");

    mqtt_config_.topic =
        this->declare_parameter<std::string>("mqtt_subscribe_topic", "esp32/imu");

    RCLCPP_INFO(this->get_logger(), "LifecycleManager node is ready");
    device_path_ = this->declare_parameter<std::string>("device_path", "/dev/ttyUSB0");
    baudrate_ = this->declare_parameter<int>("baudrate", 115200);
    communication_type_ = this->declare_parameter<std::string>("comm_t", "serial");

    hw_interface = std::make_shared<HardwareInterface>(mqtt_config_);
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
LifecycleManager::on_error(const rclcpp_lifecycle::State&) {
    RCLCPP_ERROR(this->get_logger(), "Error occurred in lifecycle...");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
LifecycleManager::on_configure(const rclcpp_lifecycle::State&) {
    RCLCPP_INFO(this->get_logger(), "configuring lifecycle...");

    if (communication_type_ == "mqtt") {
        RCLCPP_INFO(this->get_logger(), "Setting up MQTT communication...");
        hw_interface->mqtt_configure();
    } else {
        RCLCPP_INFO(this->get_logger(), "Using serial communication.");

        if (!hw_interface->uart_open_device(device_path_, baudrate_)) {
            RCLCPP_ERROR(this->get_logger(), "Failed to open hardware device during configuration.");
            return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
        }
    }

    RCLCPP_INFO(this->get_logger(), "Lifecycle configured successfully.");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
LifecycleManager::on_cleanup(const rclcpp_lifecycle::State&) {
    RCLCPP_INFO(this->get_logger(), "cleaning up lifecycle...");
    if (communication_type_ == "mqtt") {
        hw_interface->mqtt_close_connection();
    } else {
        if (hw_interface->uart_device_is_open()) {
            hw_interface->uart_stop_read();
            hw_interface->uart_close_device();
        }
    }

    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
LifecycleManager::on_activate(const rclcpp_lifecycle::State&) {
    RCLCPP_INFO(this->get_logger(), "activating lifecycle...");

    if (communication_type_ == "mqtt") {
        RCLCPP_INFO(this->get_logger(), "Reading on MQTT...");
        hw_interface->mqtt_start_listen();
        return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;

    } else {
        RCLCPP_INFO(this->get_logger(), "Reading on Serial...");
        hw_interface->uart_start_read();
    }

    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
LifecycleManager::on_deactivate(const rclcpp_lifecycle::State&) {
    RCLCPP_INFO(this->get_logger(), "deactivating lifecycle...");

    if (communication_type_ == "mqtt")
    {
        hw_interface->mqtt_stop_listen();
        return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;

    } else
    {
        if (!hw_interface->uart_device_is_open()) {
            RCLCPP_ERROR(this->get_logger(), "Hardware device is not open during activation.");
            hw_interface->uart_close_device();
        }
        RCLCPP_INFO(this->get_logger(), "Hardware device is open,closing device...");
        hw_interface->uart_stop_read();

        RCLCPP_INFO(this->get_logger(), "Lifecycle deactivated successfully.");
        return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
    }
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
LifecycleManager::on_shutdown(const rclcpp_lifecycle::State&) {
    if (communication_type_ == "mqtt") {
        hw_interface->mqtt_close_connection();
        return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
    } else {
        if (hw_interface->uart_device_is_open()) {
            hw_interface->uart_stop_read();
            hw_interface->uart_close_device();
        }
    }

    RCLCPP_INFO(this->get_logger(), "shutting down lifecycle...");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
}

}  // namespace assignments::two::g2_2025_lifecycle_node
