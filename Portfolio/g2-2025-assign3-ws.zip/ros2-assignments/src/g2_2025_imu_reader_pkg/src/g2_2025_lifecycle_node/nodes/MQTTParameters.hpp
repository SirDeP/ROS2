#pragma once

#include <string>

namespace assignments::two {

struct MQTTParameters {
  std::string server_address;
  std::string client_id;
  std::string topic;
};

} // namespace assignments::two
