/* main.cpp
 * Entry point for lifecycle node
 *
 * Reviewed by: <x>
 * Changelog:
 * [23-09-2025] Wessel T: Simplified main.cpp to entry point only
 */

#include "rclcpp/rclcpp.hpp"

#include "nodes/HardwareInterface.hpp"
#include "nodes/LifecycleManager.hpp"

int main(int argc, char *argv[]) {
    rclcpp::init(argc, argv);

    auto node = std::make_shared<assignments::two::g2_2025_lifecycle_node::LifecycleManager>();

    rclcpp::spin(node->get_node_base_interface());
    rclcpp::shutdown();

    return 0;
}
