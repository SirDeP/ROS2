#include <gtest/gtest.h>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_lifecycle/lifecycle_node.hpp>
#include <lifecycle_msgs/msg/state.hpp>

#include "g2_2025_lifecycle_node/nodes/LifecycleManager.hpp"

using namespace assignments::two::g2_2025_lifecycle_node;

class LifecycleManagerTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Initialize ROS2
        rclcpp::init(0, nullptr);
    }

    void TearDown() override {
        // Shutdown ROS2
        rclcpp::shutdown();
    }
};

TEST_F(LifecycleManagerTest, ConstructorTest) {
    // Test 1: Verifies that LifecycleManager can be instantiated without crashing
    ASSERT_NO_THROW({
        auto node = std::make_shared<LifecycleManager>();
        EXPECT_NE(node, nullptr);
    });
}

TEST_F(LifecycleManagerTest, ParameterDeclarationTest) {
    // Test 2: Verify all required parameters are declared with correct defaults
    auto node = std::make_shared<LifecycleManager>();

    // Check that parameters exist
    auto device_path = node->get_parameter("device_path").as_string();
    auto baudrate = node->get_parameter("baudrate").as_int();
    auto comm_t = node->get_parameter("comm_t").as_string();

    EXPECT_EQ(device_path, "/dev/ttyUSB0");
    EXPECT_EQ(baudrate, 115200);
    EXPECT_EQ(comm_t, "serial");
}

TEST_F(LifecycleManagerTest, ParameterRuntimeReadTest) {
    // Test 3: Verify parameters can be read at runtime
    auto node = std::make_shared<LifecycleManager>();

    // Set new parameter values
    node->set_parameter(rclcpp::Parameter("device_path", "/dev/ttyACM0"));
    node->set_parameter(rclcpp::Parameter("comm_t", "mqtt"));

    // Verify new values are read
    auto device_path = node->get_parameter("device_path").as_string();
    auto comm_t = node->get_parameter("comm_t").as_string();

    EXPECT_EQ(device_path, "/dev/ttyACM0");
    EXPECT_EQ(comm_t, "mqtt");
}


TEST_F(LifecycleManagerTest, InitialStateTest) {
    // Test 4: Verify node starts in UNCONFIGURED state
    auto node = std::make_shared<LifecycleManager>();

    EXPECT_EQ(node->get_current_state().id(), lifecycle_msgs::msg::State::PRIMARY_STATE_UNCONFIGURED);
}

TEST_F(LifecycleManagerTest, ConfigureSerialModeTest) {
    // Test 5: Test on_configure in serial communication mode
    auto node = std::make_shared<LifecycleManager>();

    // Use /dev/null as a safe test device
    node->set_parameter(rclcpp::Parameter("device_path", "/dev/null"));
    node->set_parameter(rclcpp::Parameter("comm_t", "serial"));

    // Attempt to configure
    node->configure();

    // Check state after configure
    auto state_id = node->get_current_state().id();
    // Should be INACTIVE (2) if successful or UNCONFIGURED (0) if failed
    EXPECT_TRUE(state_id == lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE ||
                state_id == lifecycle_msgs::msg::State::PRIMARY_STATE_UNCONFIGURED);
}

TEST_F(LifecycleManagerTest, ConfigureMQTTModeTest) {
    // Test 6: Test on_configure in MQTT communication mode
    auto node = std::make_shared<LifecycleManager>();

    node->set_parameter(rclcpp::Parameter("comm_t", "mqtt"));

    // Attempt to configure (MQTT setup doesn't require actual broker)
    node->configure();

    //should be INACTIVE or UNCONFIGURED
    auto state_id = node->get_current_state().id();
    EXPECT_TRUE(state_id == lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE ||
                state_id == lifecycle_msgs::msg::State::PRIMARY_STATE_UNCONFIGURED);
}

TEST_F(LifecycleManagerTest, ConfigureSerialFailureTest) {
    auto node = std::make_shared<LifecycleManager>();

    // Use /dev/null which should open successfully for this test
    node->set_parameter(rclcpp::Parameter("device_path", "/dev/null"));
    node->set_parameter(rclcpp::Parameter("comm_t", "serial"));

    // Attempt to configure
    node->configure();

    SUCCEED();
}

TEST_F(LifecycleManagerTest, DeactivateSerialModeTest) {
    // Test 8: Test on_deactivate in serial communication mode
    auto node = std::make_shared<LifecycleManager>();

    node->set_parameter(rclcpp::Parameter("device_path", "/dev/null"));
    node->set_parameter(rclcpp::Parameter("comm_t", "serial"));

    // Configure to INACTIVE state
    node->configure();
    auto config_state = node->get_current_state().id();

    if (config_state == lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE) {
        // Deactivate from INACTIVE
        node->deactivate();
        auto final_state = node->get_current_state().id();
        // Should still be in INACTIVE or return to UNCONFIGURED
        EXPECT_TRUE(final_state == lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE ||
                    final_state == lifecycle_msgs::msg::State::PRIMARY_STATE_UNCONFIGURED);
    }
}


TEST_F(LifecycleManagerTest, DevicePathParameterTest) {
    // Test 24: Verify device_path parameter is correctly used
    auto node = std::make_shared<LifecycleManager>();

    // Test multiple device paths
    std::vector<std::string> device_paths = {"/dev/ttyUSB0", "/dev/ttyACM0", "/dev/null"};

    for (const auto& path : device_paths) {
        node->set_parameter(rclcpp::Parameter("device_path", path));
        auto retrieved_path = node->get_parameter("device_path").as_string();
        EXPECT_EQ(retrieved_path, path);
    }
}

TEST_F(LifecycleManagerTest, BaudRateParameterTest) {
    // Test 25: Verify baudrate parameter is correctly used
    auto node = std::make_shared<LifecycleManager>();

    // Test multiple baud rates
    std::vector<int> baud_rates = {9600, 115200, 230400};

    for (int baud : baud_rates) {
        node->set_parameter(rclcpp::Parameter("baudrate", baud));
        auto retrieved_baud = node->get_parameter("baudrate").as_int();
        EXPECT_EQ(retrieved_baud, baud);
    }
}

TEST_F(LifecycleManagerTest, ParameterUpdateBehaviorTest) {
    // Test 19: Test that parameter changes are respected across transitions
    auto node = std::make_shared<LifecycleManager>();

    // Start with serial
    node->set_parameter(rclcpp::Parameter("comm_t", "serial"));
    node->set_parameter(rclcpp::Parameter("device_path", "/dev/null"));

    auto comm_type = node->get_parameter("comm_t").as_string();
    EXPECT_EQ(comm_type, "serial");

    // Switch to MQTT
    node->set_parameter(rclcpp::Parameter("comm_t", "mqtt"));
    comm_type = node->get_parameter("comm_t").as_string();
    EXPECT_EQ(comm_type, "mqtt");

    // Switch back to serial
    node->set_parameter(rclcpp::Parameter("comm_t", "serial"));
    comm_type = node->get_parameter("comm_t").as_string();
    EXPECT_EQ(comm_type, "serial");
}

TEST_F(LifecycleManagerTest, ResourceCleanupTest) {
    // Test 9: Verify resources are properly cleaned up
    {
        auto node = std::make_shared<LifecycleManager>();

        node->set_parameter(rclcpp::Parameter("device_path", "/dev/null"));
        node->set_parameter(rclcpp::Parameter("comm_t", "serial"));

        // Just configure, don't activate (avoid thread spawning)
        node->configure();

        // Node goes out of scope; verify no crashes
    }

    // If we reach here without crashes, cleanup was successful
    SUCCEED();
}

TEST_F(LifecycleManagerTest, ErrorLoggingTest) {
    // Test 10: Verify error messages are logged during failures
    auto node = std::make_shared<LifecycleManager>();

    // Set invalid device path to trigger error
    node->set_parameter(rclcpp::Parameter("device_path", "/dev/nonexistent_device_xyz"));
    node->set_parameter(rclcpp::Parameter("comm_t", "serial"));

    // This should attempt to configure
    node->configure();

    // The node may still transition state, but we verify it handles errors gracefully
    // by not crashing
    SUCCEED();
}

TEST_F(LifecycleManagerTest, HardwareInterfaceIntegrationTest) {
    // Test 11: Verify complete integration with HardwareInterface
    auto node = std::make_shared<LifecycleManager>();

    // Verify HardwareInterface instance is created
    EXPECT_NE(node->hw_interface, nullptr);

    // Verify we can make method calls on the hardware interface
    EXPECT_FALSE(node->hw_interface->uart_device_is_open());
}

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
