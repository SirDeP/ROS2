#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <rclcpp/rclcpp.hpp>

#include "config/ConfigManager.hpp"

using namespace assignments::two;

static const std::string TEST_CONFIG_CONTENT = R"(
[database]
host = "test_host"
port = 1234
dbname = "test_db"
user = "test_user"
password = "test_password"
timeout = 60
ssl = true

[database.pool]
min_connections = 2
max_connections = 20
)";

static const std::string TEST_CONFIG_NO_POOL_CONTENT = R"(
[database]
host = "localhost"
port = 5432
dbname = "imu_data"
user = "postgres"
password = "postgres"
)";


class ConfigManagerTest : public ::testing::Test {
protected:
    void SetUp() override {
        rclcpp::init(0, nullptr);
        node_ = std::make_shared<rclcpp::Node>("test_config_node");
    }

    void TearDown() override {
        // Clean up temporary files
        if (std::filesystem::exists(temp_config_file_)) {
            std::filesystem::remove(temp_config_file_);
        }

        node_.reset();
        rclcpp::shutdown();
    }

    void create_temp_config_file() {
        temp_config_file_ = "test_config.toml";
        std::ofstream file(temp_config_file_);
        file << TEST_CONFIG_CONTENT;
        file.close();
    }

    std::shared_ptr<rclcpp::Node> node_;
    std::string temp_config_file_;
};

TEST_F(ConfigManagerTest, ConstructorTest) {
    // Test ConfigManager can be constructed with logger
    ConfigManager config_manager(node_->get_logger());
    // Constructor should not crash
    SUCCEED();
}

TEST_F(ConfigManagerTest, LoadValidConfigTest) {
    create_temp_config_file();

    ConfigManager config_manager(node_->get_logger());
    bool result = config_manager.load_config(temp_config_file_);

    EXPECT_TRUE(result);
    EXPECT_TRUE(config_manager.is_loaded());
}

TEST_F(ConfigManagerTest, LoadInvalidFileTest) {
    ConfigManager config_manager(node_->get_logger());
    bool result = config_manager.load_config("non_existent_file.toml");

    EXPECT_FALSE(result);
    EXPECT_FALSE(config_manager.is_loaded());
}

TEST_F(ConfigManagerTest, DatabaseConfigParsingTest) {
    create_temp_config_file();

    ConfigManager config_manager(node_->get_logger());
    config_manager.load_config(temp_config_file_);

    auto db_config = config_manager.get_database_config();

    ASSERT_TRUE(db_config.has_value());
    EXPECT_EQ(db_config->host, "test_host");
    EXPECT_EQ(db_config->port, 1234);
    EXPECT_EQ(db_config->dbname, "test_db");
    EXPECT_EQ(db_config->user, "test_user");
    EXPECT_EQ(db_config->password, "test_password");
    EXPECT_EQ(db_config->timeout, 60);
    EXPECT_TRUE(db_config->ssl);
    EXPECT_EQ(db_config->min_connections, 2);
    EXPECT_EQ(db_config->max_connections, 20);
}

TEST_F(ConfigManagerTest, DatabaseConfigWithoutPoolTest) {
    // Create config without pool section
    std::ofstream file("test_config_no_pool.toml");
    file << TEST_CONFIG_NO_POOL_CONTENT;
    file.close();

    ConfigManager config_manager(node_->get_logger());
    config_manager.load_config("test_config_no_pool.toml");

    auto db_config = config_manager.get_database_config();

    ASSERT_TRUE(db_config.has_value());
    EXPECT_EQ(db_config->host, "localhost");
    EXPECT_EQ(db_config->port, 5432);
    EXPECT_EQ(db_config->min_connections, 1);  // default
    EXPECT_EQ(db_config->max_connections, 10); // default

    std::filesystem::remove("test_config_no_pool.toml");
}

TEST_F(ConfigManagerTest, GetConfigWithoutLoadingTest) {
    ConfigManager config_manager(node_->get_logger());

    auto db_config = config_manager.get_database_config();

    EXPECT_FALSE(db_config.has_value());
    EXPECT_FALSE(config_manager.is_loaded());
}
