#include <gtest/gtest.h>
#include <rclcpp/rclcpp.hpp>

#include "database/DatabaseManager.hpp"

using namespace assignments::two;

class DatabaseManagerTest : public ::testing::Test {
protected:
    void SetUp() override {
        rclcpp::init(0, nullptr);

        node_ = std::make_shared<rclcpp::Node>("test_db_node");
        db_manager_ = std::make_unique<DatabaseManager>(node_->get_logger());
    }

    void TearDown() override {
        db_manager_.reset();
        node_.reset();
        rclcpp::shutdown();
    }

    std::shared_ptr<rclcpp::Node> node_;
    std::unique_ptr<DatabaseManager> db_manager_;
};

TEST_F(DatabaseManagerTest, ConstructorTest) {
    // Test DatabaseManager can be constructed
    ASSERT_NE(db_manager_, nullptr);
}

TEST_F(DatabaseManagerTest, ConnectionStatusTest) {
    // Should return a boolean (connected or not) — here no DB configured so expect false
    bool status = db_manager_->is_connected();
    EXPECT_TRUE(status == true || status == false);
}

TEST_F(DatabaseManagerTest, StoreIMUDataWhenNotConnected) {
    // Without a real DB connection, storing IMU data should return false
    bool result = db_manager_->store_imu_data(1.0, 2.0, 3.0, 0.1, 0.2, 0.3);
    EXPECT_FALSE(result);
}

TEST_F(DatabaseManagerTest, CreateTablesNoCrash) {
    // create_tables should be safe to call even when not connected (no throw)
    EXPECT_NO_THROW(db_manager_->create_tables());
}
