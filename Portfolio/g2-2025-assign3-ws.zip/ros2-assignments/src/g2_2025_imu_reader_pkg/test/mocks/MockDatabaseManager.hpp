#pragma once

#include "database/DatabaseManager.hpp"

namespace assignments::two {

class MockDatabaseManager : public DatabaseManager {
public:
    explicit MockDatabaseManager(
        rclcpp::Logger logger = rclcpp::get_logger("fake_db")
    )
    : DatabaseManager(logger) {}

    bool is_connected() const override {
        return connection_status_;
    }

    void init_database() override {}

    void set_connection_status(bool status) {
        connection_status_ = status;
    }

    bool store_imu_data(
        double linear_accel_x, double linear_accel_y, double linear_accel_z,
        double angular_vel_x, double angular_vel_y, double angular_vel_z
    ) override {
        called_ = true;
        last_la_x_ = linear_accel_x;
        last_la_y_ = linear_accel_y;
        last_la_z_ = linear_accel_z;
        last_av_x_ = angular_vel_x;
        last_av_y_ = angular_vel_y;
        last_av_z_ = angular_vel_z;
        return true;
    }

    bool called_ = false;
    double last_la_x_ = 0.0, last_la_y_ = 0.0, last_la_z_ = 0.0;
    double last_av_x_ = 0.0, last_av_y_ = 0.0, last_av_z_ = 0.0;

private:
    bool connection_status_ = true;
};

} // namespace assignments::two
