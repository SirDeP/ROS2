#include <chrono>
#include <memory>
#include <rclcpp/rclcpp.hpp>
#include <gtest/gtest.h>

#include "g2_2025_imu_database_writer_node/nodes/IMUDatabaseWriter.hpp"
#include "mocks/MockDatabaseManager.hpp"
#include "sensor_msgs/msg/imu.hpp"

using namespace std::chrono_literals;
using namespace assignments::two::imu_database_writer;

class IMUDatabaseWriterTest : public ::testing::Test {
protected:
    void SetUp() override {
        rclcpp::init(0, nullptr);
        test_node_ = std::make_shared<rclcpp::Node>("test_node");

        // create mock db and inject
        mock_db_ = std::make_unique<assignments::two::MockDatabaseManager>(rclcpp::get_logger("test_mock_db"));
        mock_db_ptr_ = mock_db_.get();

        imu_node_ = std::make_shared<IMUDatabaseWriter>(std::move(mock_db_));

        // publisher in test node
        imu_publisher_ = test_node_->create_publisher<sensor_msgs::msg::Imu>("imu_data", 10);
    }

    void TearDown() override {
        imu_node_.reset();
        test_node_.reset();
        rclcpp::shutdown();
    }

    void spin_some_time(std::chrono::milliseconds duration = 200ms) {
        auto start = std::chrono::steady_clock::now();
        while (std::chrono::steady_clock::now() - start < duration) {
            rclcpp::spin_some(test_node_);
            if (imu_node_) rclcpp::spin_some(imu_node_);
            std::this_thread::sleep_for(10ms);
        }
    }

    std::shared_ptr<rclcpp::Node> test_node_;
    std::shared_ptr<IMUDatabaseWriter> imu_node_;
    std::unique_ptr<assignments::two::MockDatabaseManager> mock_db_;
    assignments::two::MockDatabaseManager* mock_db_ptr_ = nullptr;
    rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_publisher_;
};

TEST_F(IMUDatabaseWriterTest, ConstructorTest) {
    ASSERT_NE(imu_node_, nullptr);
}

TEST_F(IMUDatabaseWriterTest, ReceivesAndForwardsIMU) {
    auto msg = sensor_msgs::msg::Imu();
    msg.linear_acceleration.x = 1.23;
    msg.linear_acceleration.y = -0.5;
    msg.linear_acceleration.z = 0.0;
    msg.angular_velocity.x = 0.01;
    msg.angular_velocity.y = -0.02;
    msg.angular_velocity.z = 0.03;

    imu_publisher_->publish(msg);

    spin_some_time(300ms);

    EXPECT_TRUE(mock_db_ptr_->called_);
}
