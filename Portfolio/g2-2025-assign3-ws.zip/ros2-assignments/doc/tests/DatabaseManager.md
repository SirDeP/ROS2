# Database Manager Unit Tests

Unit tests for `DatabaseManager` are implemented in `src/g2_2025_imu_reader_pkg/test/DatabaseManager.test.cpp` using Google Test and ROS2 test utilities. The tests are designed to work reliably whether a database connection is available or not, focusing on error handling and method behavior validation.

## Test Cases

### 1. ConstructorTest

**Description:** Verifies that DatabaseManager can be created without crashing and proper initialization occurs.

- **Test Action:** Create DatabaseManager instance with ROS2 logger
- **Expected Result:** Instance created successfully without exceptions

### 2. ConnectionStatusTest

**Description:** Tests that the `is_connected()` method returns a valid boolean value.

- **Test Action:** Call `is_connected()` method
- **Expected Result:** Returns either `true` or `false` (no crashes or invalid states)

### 3. StoreIMUDataWhenNotConnected

**Description:** Verifies that storing IMU data without an active database connection fails gracefully.

- **Test Action:** Call `store_imu_data(linear_x, linear_y, linear_z, ang_x, ang_y, ang_z)` without an active DB connection
- **Expected Result:** Returns `false` and does not throw — method must check connection status before DB operations

### 4. CreateTablesNoCrash

**Description:** Verifies calling `create_tables()` without an active connection is safe.

- **Test Action:** Call `create_tables()` on a manager that is not connected
- **Expected Result:** No exception thrown; the function should be a no-op when no DB connection exists
