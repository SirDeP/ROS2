# LifecycleManager Unit Tests

Unit tests for `LifecycleManager` are implemented in `src/g2_2025_imu_reader_pkg/test/LifecycleManager.test.cpp` using Google Test and ROS2 lifecycle test utilities. The tests are designed to validate all lifecycle state transitions, parameter handling, and hardware integration without requiring actual hardware or MQTT broker connectivity.

## Test Cases

### 1. ConstructorTest

**Description:** Verifies that LifecycleManager can be instantiated without crashing and parameters are correctly declared.

- **Test Action:** Create LifecycleManager instance with default parameters
- **Expected Result:** Instance created successfully; parameters `device_path`, `baudrate`, and `comm_t` are registered with their defaults

---

### 2. ParameterDeclarationTest

**Description:** Tests that all required parameters are declared during construction with correct default values.

- **Test Action:**
  - Create LifecycleManager
  - Query parameters: `device_path`, `baudrate`, `comm_t`
- **Expected Result:**
  - `device_path` defaults to `"/dev/ttyUSB0"`
  - `baudrate` defaults to `115200`
  - `comm_t` defaults to `"serial"`

---

### 3. ParameterRuntimeReadTest

**Description:** Verifies parameters can be read at runtime and affect behavior.

- **Test Action:**
  - Set parameters via ROS2 parameter API: `device_path="/dev/ttyACM0"`, `comm_t="mqtt"`
  - Verify LifecycleManager reads the updated values
- **Expected Result:** Parameters are correctly read and stored in member variables

---

### 4. InitialStateTest

**Description:** Tests that the node starts in the `UNCONFIGURED` state.

- **Test Action:** Create LifecycleManager and check lifecycle state
- **Expected Result:** Node is in `UNCONFIGURED` state

---

### 5. ConfigureSerialModeTest

**Description:** Tests the `on_configure` callback in serial communication mode.

- **Test Action:**
  - Set `comm_t` parameter to `"serial"`
  - Call `on_configure()` with valid device path (e.g., `/dev/null` for testing)
- **Expected Result:**
  - Transition succeeds
  - Node moves to `INACTIVE` state
  - `HardwareInterface::open_device()` is called with correct parameters

---

### 6. ConfigureMQTTModeTest

**Description:** Tests the `on_configure` callback in MQTT communication mode.

- **Test Action:**
  - Set `comm_t` parameter to `"mqtt"`
  - Call `on_configure()`
- **Expected Result:**
  - Transition succeeds
  - Node moves to `INACTIVE` state
  - `HardwareInterface::mqtt_configure()` is called

---

### 7. ConfigureSerialFailureTest

**Description:** Tests graceful failure when serial device cannot be opened.

- **Test Action:**
  - Set `device_path` to non-existent path (e.g., `/dev/invalid_device`)
  - Set `comm_t` to `"serial"`
  - Call `on_configure()`
- **Expected Result:**
  - Transition handled gracefully (node doesn't crash)
  - Error logging occurs

---

### 8. DeactivateSerialModeTest

**Description:** Tests the `on_deactivate` callback in serial communication mode.

- **Test Action:**
  - Configure to `INACTIVE` state in serial mode
  - Call `on_deactivate()`
- **Expected Result:**
  - Transition handled gracefully
  - Resources are properly released

---

### 9. ResourceCleanupTest

**Description:** Tests that all resources are properly cleaned up on deactivation and shutdown.

- **Test Action:**
  - Configure node with serial settings
  - Let node go out of scope
  - Verify no crashes or resource leaks
- **Expected Result:**
  - No memory leaks
  - File descriptors are closed
  - No segmentation faults on cleanup

---

### 10. ErrorLoggingTest

**Description:** Tests that error handling works during configuration attempts.

- **Test Action:**
  - Set invalid device path and attempt configuration
  - Verify error is handled gracefully
- **Expected Result:**
  - Node doesn't crash on error
  - Error logging occurs

---

### 11. HardwareInterfaceIntegrationTest

**Description:** Tests the complete integration between LifecycleManager and HardwareInterface.

- **Test Action:**
  - Create LifecycleManager instance
  - Verify HardwareInterface instance is created and accessible
  - Verify we can call HardwareInterface methods
- **Expected Result:**
  - HardwareInterface is properly initialized
  - No segmentation faults when accessing interface methods

---

### 12. DevicePathParameterTest

**Description:** Tests that device_path parameter correctly controls serial device selection.

- **Test Action:**
  - Set `device_path` to `/dev/null`
  - Call `on_configure()` in serial mode
  - Verify correct device path is used
- **Expected Result:**
  - Configuration succeeds with correct device path

---

### 13. BaudRateParameterTest

**Description:** Tests that baudrate parameter is correctly configured.

- **Test Action:**
  - Set `baudrate` to valid value (e.g., 115200)
  - Call `on_configure()` in serial mode
- **Expected Result:**
  - Correct baud rate is passed to the hardware interface

---

### 14. ParameterUpdateBehaviorTest

**Description:** Tests that parameter changes are respected across state transitions.

- **Test Action:**
  - Set `comm_t` to `"serial"`, configure
  - Deactivate and transition back to UNCONFIGURED
  - Change `comm_t` to `"mqtt"`
  - Re-configure with new communication mode
- **Expected Result:**
  - Communication mode switches work correctly
  - Parameter changes are respected

---

## Test Organization

Tests are organized into logical groups:

1. **Construction & Initialization** (Tests 1-3): Basic object creation and parameter setup
2. **State Transitions & Configuration** (Tests 4-7): Lifecycle callbacks and state validation
3. **Parameter Validation** (Tests 12-13): Parameter binding and influence on behavior
4. **Complete Sequences** (Test 14): Parameter switching across state transitions
5. **Resource & Thread Safety** (Tests 8-9): Resource cleanup and safe deactivation
6. **Error Handling & Integration** (Tests 10-11): Error resilience and component integration

---

## Test Execution

### Run All Tests

```bash
# From workspace root
colcon test --packages-select g2_2025_imu_reader_pkg
```

### Run Specific Test Suite

```bash
# Run only LifecycleManager tests
colcon test --packages-select g2_2025_imu_reader_pkg --ctest-args -R "LifecycleManager"
```

### Run with Verbose Output

```bash
colcon test --packages-select g2_2025_imu_reader_pkg --ctest-args --verbose
```

### Run Tests Directly

```bash
# From workspace root
./build/g2_2025_imu_reader_pkg/g2_2025_imu_reader_pkg_test_lifecycle_manager
```

---
