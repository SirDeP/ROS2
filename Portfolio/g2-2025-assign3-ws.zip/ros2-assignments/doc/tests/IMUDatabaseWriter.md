# IMU Database Writer Unit Tests

Unit tests for `IMUDatabaseWriter` are implemented in `src/g2_2025_imu_reader_pkg/test/IMUDatabaseWriter.test.cpp` using Google Test and ROS2 test utilities. These tests validate that the node subscribes to the `imu_data` topic, receives IMU messages, and forwards parsed values to the `DatabaseManager` interface. Tests use dependency injection with a mock `DatabaseManager` to avoid requiring a real database connection.

## Test Cases

### 1. ConstructorTest

**Description:** Verifies that `IMUDatabaseWriter` can be constructed.

- **Test Action:** Create `IMUDatabaseWriter` node with a `MockDatabaseManager`
- **Expected Result:** Node instance created successfully without exceptions

### 2. ReceivesAndForwardsIMU

**Description:** Tests that the node receives IMU messages on the `imu_data` topic and calls `store_imu_data(...)` on the injected database manager.

- **Expected Result:** Mock's `called_` flag is set to `true`, confirming the node forwarded the IMU data to the database manager
