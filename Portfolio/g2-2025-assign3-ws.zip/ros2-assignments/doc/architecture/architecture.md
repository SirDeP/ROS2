# ROS2 IMU Reader — Design Document

## Project Overview

This projects reads data from a ESP32 communicating with serial or MQTT and writes this into a database for further processing

## System Architecture

### High-Level Architecture

The system consists of multiple ROS2 nodes that communicate through standardized topics and services to process imu data and store it in a database

### Key Design Principles

- **Microservices Architecture**: Each component has a single responsibility
- **Asynchronous Communication**: Uses ROS2 topics and services for loose coupling
- **Data Persistence**: Centralized database management for datastorage
- **Comprehensive Testing**: Unit tests ensure code reliability

## System Components

### ESP32-IMU
*For ESP32 specific documentation see [ESP32-IMU.md](IMU/ESP32-IMU.md)*

### Core Nodes

#### 1. IMU Databse writer Node
**Namespace**: `assignments::two::imu_database_writer`

**Brief Description**: Recieves and stores IMU data.

**Key Features**: Database persistence

*For detailed documentation, see: [IMUDatabaseWriter.md](nodes/IMUDatabaseWriter.md)*

#### 2. LifeCycle Node
**Namespace**: `assignments::two::lifecycle_manager`

**Brief Description**: Configures low level communication and manages the hardware interface to read on either serial or mqtt comunications.

**Key Features**: Configuration of communications, device read activation and deactivation.

*For detailed documentation, see: [LifecycleManager.md](nodes/LifecycleManager.md)*

#### 3. Hardware Interface
**Namespace**: `assignments::two::hardware_interface`

**Brief Description**: Manages low-level communication protocols (Serial/MQTT) for ESP32 data acquisition and forwards raw sensor data to processing nodes.

**Key Features**: Multi-protocol communication support, connection management, raw data parsing and streaming.

*For detailed documentation, see: [HardwareInterface.md](nodes/HardwareInterface.md)*

### Data Management

#### DatabaseManager
**Brief Description**: PostgreSQL database interface handling connections, table management, and data persistence.

**Key Features**: Connection management, automatic table creation, student enrollment tracking, exam result storage

*For detailed documentation, see: [DatabaseManager.md](../DatabaseManager.md)*

#### ConfigManager
**Brief Description**: TOML-based configuration management system allowing runtime configuration without recompilation.

**Key Features**: Automatic config file discovery, type-safe TOML parsing, database connection configuration

*For detailed documentation, see: [ConfigManager.md](../ConfigManager.md)*

### Communication Interfaces

#### ROS2 Message Interface
**Brief Description**: This project uses the ROS2 standard IMU sensor message

## System Workflow

### 1. Imu data  Processing

1. **Input**: IMU data is sent from the ESP32 to the lifecycle node
2. **Collection**: The lifcycle node recieves the data via a serial or MQTT connection
4. **Data passthrough**: When data is recieved it is sent to the database writer

### 2. Data Management

1. **Database Storage**: IMU data is persisted/stored in the database

## Configuration Management

### TOML Configuration Structure

The system uses TOML files for environment-specific configuration:

```toml
[database]
host = "localhost"
port = 5432
name = "grade_db"
user = "grade_user"
password = "secure_password"

[grade_calculation]
collection_amount = 5
min_grade = 10
max_grade = 100

[logging]
level = "INFO"
output_file = "grade_system.log"
```

## Testing

The testing documentation can be found in the [doc/tests](/doc/tests/) folder for each node
