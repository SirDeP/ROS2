# IMU (MPU6886) ESP-IDF
=====================

Small ESP-IDF project that reads an MPU6886 IMU over I2C and publishes readings over MQTT.
Includes an option to run WiFi in STA (client) or AP (access point) mode.

### Features

- I2C communication functions for MPU6886 (accelerometer, gyro, temp)
- MQTT client using `esp-mqtt`
- WiFi: STA or AP mode selectable at build time
- AP mode defaults to static IP 192.168.10.1/24 (configurable in code)
- MQTT, Serial toggle using the boot button on the esp32

## Quick start

### Prerequisites

- ESP-IDF installed and activated (the repo was developed with ESP-IDF v5.x).
- Toolchain and Python deps per ESP-IDF instructions.

### Build and flash

From the IMU root:

```bash
# configure project options
idf.py menuconfig

# build
idf.py build

# flash and monitor (set your serial port)
idf.py -p /dev/ttyUSB0 flash monitor
```

## Project Configuration (menuconfig)

Open `idf.py menuconfig` and there you will see the `ESP32 IMU Project Configuration` submenu where you can configure specific data for I2C, MQTT and WIFI

### I2C
---
In the `I2C Master configuration` submenu there are three options:
- SCL GPIO Num  - Default 21 - GPIO used for I2C SDA
- SDA GPIO Num  - Default 22 - GPIO used for I2C SCL
- Master Frequency - Default 100000hz - I2C bus speed

### MQTT

- Broker URI - Default: `"mqtt://192.168.4.2:1883"`
- MQTT Topic - Default: `"esp32/imu"`

### WiFi / network

- Toggle AP mode at build time by enabling `CONFIG_WIFI_AP_MODE` in menuconfig. If enabled the firmware will start as an access point on boot; if disabled the device starts as a station and attempts to connect to the configured SSID using the set Password
- Toggle AP mode swaps the available settings when toggled between AP conf- and station configurations respectively
- AP credentials can be set with `WiFi AP SSID` and `Wifi AP Password`.
- Station credentials can be set with `WiFi SSID` and `WiFi Password`.

### AP IP / DHCP

- The AP is configured by default to use a static IP of `192.168.4.1` with netmask `255.255.255.0` and a DHCP server is started so clients receive addresses on that subnet.

## Notes about units and macros

- The macro `SF_RAD_S` (in `main/mpu6886.h`) is the degrees-to-radians conversion factor: PI/180. Gyroscope readings are converted from degrees/sec to radians/sec using this scale.
- Sensitivity scale constants (e.g. `ACCEL_SO_2G`, `GYRO_SO_250DPS`) are used to convert raw sensor counts to physical units.

## Troubleshooting

- "`MQTT_TOPIC` undefined" at build time: run menuconfig
- "I2C init failed": confirm SDA/SCL pins in menuconfig or wiring.

## Files of interest

- `main/mpu6886.c` - main application, WiFi init, MQTT publish loop
- `main/mpu6886.h` - sensor constants and types
