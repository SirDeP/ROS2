# IMUDatabaseWriter (`assignments::two::imu_database_writer`)

The `IMUDatabaseWriter` node subscribes to IMU sensor data (`sensor_msgs/msg/Imu`) and saves published data into the PostgreSQL database via the `DatabaseManager`. It is a lightweight sink node intended record IMU measurements (linear acceleration and angular velocity) together with timestamps.

## Implementation Details

**Parameters**

- No node-specific parameters are required by default. Database connection and table configuration are handled by `DatabaseManager` and the project's `ConfigManager`.

**Constructor**
```cpp
IMUDatabaseWriter()
```
- Initializes ROS2 node with name `imu_database_writer`
- Creates `DatabaseManager` instance
- Creates a subscription to the `imu_data` topic using `sensor_msgs::msg::Imu`

## Core Functionality

**`void imu_data_callback(const sensor_msgs::msg::Imu::SharedPtr msg)`**
- Primary callback invoked whenever an IMU message is received
- Forwards: linear acceleration (x, y, z) and angular velocity (x, y, z) to `DatabaseManager::store_imu_data`

## ROS2 Interface

**Subscriptions**
- `imu_data` (sensor_msgs/msg/Imu)
  - Receives raw IMU samples.
