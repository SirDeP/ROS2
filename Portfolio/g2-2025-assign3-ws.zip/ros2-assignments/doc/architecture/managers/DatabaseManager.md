# DatabaseManager (`assignments::two::DatabaseManager`)

## Overview

The `DatabaseManager` class is a PostgreSQL database interface for the ROS2 IMU data collection system.
It handles all database operations including connection management, table creation and data storage.

## Implementation Details

### Dependencies
- **pqxx**: Modern C++ PostgreSQL library for database connectivity
- **rclcpp**: ROS2 C++ client library for logging
- **ConfigManager**: Configuration manager for database settings

### Key Components

#### Constructor
```cpp
DatabaseManager(rclcpp::Logger logger)
```
- Initializes the database manager with ROS2 logging
- Creates a ConfigManager instance for configuration handling
- Automatically calls `init_database()` to establish connection and setup

#### Connection Management

**`bool connect(const std::string& connection_string)`**
> Returns `true` on successful connection, `false` on failure

- Establishes connection to PostgreSQL database using connection information from the config TOML
- Connection string format: `"host=localhost port=5432 dbname=imu_data user=postgres password=postgres"`

**`bool is_connected() const`**
>  Returns `true` if connection exists and is open

- Check for active database connection status

#### Database Initialization

**`void init_database()`**
- Database setup process
- Loads configuration from ConfigManager
- Establishes connection using configuration settings
- Creates necessary tables and inserts sample data
- Error handling for configuration and connection failures

**`void create_tables()`**
- Creates all required database tables using SQL queries from `SQLQueries.hpp`
- Tables created:
  - `imu_data`: IMU sensor readings with linear acceleration and angular velocity data
- Uses transactions for atomic table creation

### Data Operations

#### IMU Data Storage

**`bool store_imu_data(double linear_accel_x, double linear_accel_y, double linear_accel_z, double angular_vel_x, double angular_vel_y, double angular_vel_z)`**
> Returns `true` on successful storage, `false` on failure

- Stores IMU sensor readings in the database
- Parameters:
  - `linear_accel_x`: Linear acceleration on X-axis
  - `linear_accel_y`: Linear acceleration on Y-axis
  - `linear_accel_z`: Linear acceleration on Z-axis
  - `angular_vel_x`: Angular velocity around X-axis
  - `angular_vel_y`: Angular velocity around Y-axis
  - `angular_vel_z`: Angular velocity around Z-axis
- Automatically adds timestamp on insertion

### Logging

- Uses ROS2 logger with `[DBS]` prefix for database operations
- Different log levels:
  - `INFO`: Successful operations, connection status
  - `ERROR`: SQL errors, connection failures, configuration issues
  - `WARN`: Non-critical issues, missing configurations


### Usage Examples

#### Basic Database Setup
```cpp
// Create DatabaseManager with ROS2 logger
DatabaseManager db_manager(node->get_logger());

// Check connection status
if (db_manager.is_connected()) {
    // Database ready for operations
    bool success = db_manager.store_imu_data(1.2, -0.5, 9.8, 0.01, 0.02, 0.03);
    if (success) {
        RCLCPP_INFO(logger, "IMU data stored successfully");
    }
}
```
