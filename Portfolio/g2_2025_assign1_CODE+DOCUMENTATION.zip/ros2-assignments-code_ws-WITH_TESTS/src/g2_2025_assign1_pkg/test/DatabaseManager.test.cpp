#include <gtest/gtest.h>
#include <rclcpp/rclcpp.hpp>

#include "database/DatabaseManager.hpp"
#include "database/StudentCourse.hpp"

using namespace assignments::one;

class DatabaseManagerTest : public ::testing::Test {
protected:
    void SetUp() override {
        rclcpp::init(0, nullptr);

        node_ = std::make_shared<rclcpp::Node>("test_db_node");
        db_manager_ = std::make_unique<DatabaseManager>(node_->get_logger());
    }

    void TearDown() override {
        db_manager_.reset();
        node_.reset();
        rclcpp::shutdown();
    }

    std::shared_ptr<rclcpp::Node> node_;
    std::unique_ptr<DatabaseManager> db_manager_;
};

TEST_F(DatabaseManagerTest, ConstructorTest) {
    // Test DatabaseManager can be constructed
    ASSERT_NE(db_manager_, nullptr);
}

TEST_F(DatabaseManagerTest, ConnectionStatusTest) {
    bool status = db_manager_->is_connected();

    EXPECT_TRUE(status == true || status == false);
}

TEST_F(DatabaseManagerTest, QueuePendingCombinationsTest) {
    auto combinations = db_manager_->queue_pending_combinations();

    EXPECT_GE(combinations.size(), 0);
}

TEST_F(DatabaseManagerTest, StoreExamResultTest) {
    bool result = db_manager_->store_exam_result("TestStudent", "TestCourse", 85);

    EXPECT_TRUE(result == true || result == false);
}

TEST_F(DatabaseManagerTest, EnrollStudentTest) {
    StudentCourse sc;
    sc.student_name = "TestStudent";
    sc.course_name = "TestCourse";

    bool result = db_manager_->enroll_student_into_course(sc);

    EXPECT_TRUE(result == true || result == false);
}

TEST_F(DatabaseManagerTest, GetFinalGradeTest) {
    StudentCourse sc;
    sc.student_name = "NonExistentStudent";
    sc.course_name = "NonExistentCourse";

    int grade = db_manager_->get_final_course_grade(sc);

    EXPECT_EQ(grade, -1);
}

TEST_F(DatabaseManagerTest, StoreFinalResultTest) {
    StudentCourse sc;
    sc.student_name = "TestStudent";
    sc.course_name = "TestCourse";

    bool result = db_manager_->store_final_course_result(sc, 3, 75, false);

    EXPECT_TRUE(result == true || result == false);
}
