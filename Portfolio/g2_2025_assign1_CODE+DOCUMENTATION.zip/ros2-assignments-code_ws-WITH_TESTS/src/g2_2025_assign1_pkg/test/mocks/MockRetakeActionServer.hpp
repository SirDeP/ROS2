#pragma once

namespace assignments::one {

class MockRetakeActionServer {
public:
    MockRetakeActionServer(std::shared_ptr<rclcpp::Node> node) : node_(node) {
        action_server_ = rclcpp_action::create_server<g2_2025_assign1_interfaces_pkg::action::Retake>(
            node_,
            "retake_action",
            std::bind(&MockRetakeActionServer::handle_goal, this, std::placeholders::_1, std::placeholders::_2),
            std::bind(&MockRetakeActionServer::handle_cancel, this, std::placeholders::_1),
            std::bind(&MockRetakeActionServer::handle_accepted, this, std::placeholders::_1)
        );
    }

    rclcpp_action::GoalResponse handle_goal(
        const rclcpp_action::GoalUUID & uuid,
        std::shared_ptr<const g2_2025_assign1_interfaces_pkg::action::Retake::Goal> goal
    ) {
        (void)uuid;
        received_goals_.push_back(*goal);
        return goal_response_;
    }

    rclcpp_action::CancelResponse handle_cancel(
        const std::shared_ptr<rclcpp_action::ServerGoalHandle<g2_2025_assign1_interfaces_pkg::action::Retake>> goal_handle
    ) {
        (void)goal_handle;
        cancel_requests++;
        return rclcpp_action::CancelResponse::ACCEPT;
    }

    void handle_accepted(const std::shared_ptr<rclcpp_action::ServerGoalHandle<g2_2025_assign1_interfaces_pkg::action::Retake>> goal_handle) {
        accepted_goals++;

        // Simulate immediate success
        auto result = std::make_shared<g2_2025_assign1_interfaces_pkg::action::Retake::Result>();
        result->result = 0.0;
        goal_handle->succeed(result);
    }

    void set_goal_response(rclcpp_action::GoalResponse response) {
        goal_response_ = response;
    }

    std::vector<g2_2025_assign1_interfaces_pkg::action::Retake::Goal> received_goals_;
    int accepted_goals = 0;
    int cancel_requests = 0;

private:
    std::shared_ptr<rclcpp::Node> node_;
    rclcpp_action::Server<g2_2025_assign1_interfaces_pkg::action::Retake>::SharedPtr action_server_;
    rclcpp_action::GoalResponse goal_response_ = rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE;
};

} // namespace assignments::one
