#pragma once

#include "database/DatabaseManager.hpp"

namespace assignments::one {

struct MockStoredResult {
    StudentCourse sc;
    int exam_count;
    int final_grade;
    bool is_retake;
};

class MockDatabaseManager : public DatabaseManager {
public:
    explicit MockDatabaseManager(
        rclcpp::Logger logger = rclcpp::get_logger("fake_db")
    )
    : DatabaseManager(logger) {}

    bool is_connected() const override {
        return connection_status_;
    }

    void init_database() override {}

    void set_connection_status(bool status) {
        connection_status_ = status;
    }

    std::vector<StudentCourse> get_failed_course_results() {
        return failed_students_;
    }

    bool store_final_course_result(
        const StudentCourse& sc,
        int exam_count,
        int final_grade,
        bool is_retake
    ) {
        stored_results.push_back({ sc, exam_count, final_grade, is_retake });
        return true;
    }

    bool update_retake_status(const StudentCourse& sc) {
        retake_status_updates.push_back(sc);
        return true;
    }

    void clear_failed_students() {
        failed_students_.clear();
    }

    void add_failed_student(const std::string& student_name, const std::string& course_name) {
        StudentCourse sc;
        sc.student_name = student_name;
        sc.course_name = course_name;
        failed_students_.push_back(sc);
    }

    void set_failed_students(const std::vector<StudentCourse>& failed_students) {
        failed_students_ = failed_students;
    }

    std::vector<MockStoredResult> stored_results;
    std::vector<StudentCourse> retake_status_updates;

private:
    std::vector<StudentCourse> failed_students_;
    bool connection_status_ = true;
};

} // namespace assignments::one
