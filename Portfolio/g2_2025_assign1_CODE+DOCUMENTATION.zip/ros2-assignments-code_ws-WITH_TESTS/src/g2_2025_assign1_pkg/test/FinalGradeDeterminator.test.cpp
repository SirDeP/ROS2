#include <chrono>
#include <memory>
#include <rclcpp/rclcpp.hpp>
#include <gtest/gtest.h>

#include "g2_2025_final_grade_determinator_node/nodes/FinalGradeDeterminator.hpp"
#include "database/DatabaseManager.hpp"
#include "g2_2025_assign1_interfaces_pkg/msg/exam.hpp"
#include "g2_2025_assign1_interfaces_pkg/msg/student.hpp"
#include "g2_2025_assign1_interfaces_pkg/srv/exams.hpp"

#include "mocks/MockDatabaseManager.hpp"

using namespace std::chrono_literals;
using namespace assignments::one::g2_2025_final_grade_determinator_node;

class FinalGradeDeterminatorTest : public ::testing::Test {
protected:
    void SetUp() override {
        rclcpp::init(0, nullptr);

        test_node_ = std::make_shared<rclcpp::Node>("test_node");

        // Subscriber to capture student messages
        student_subscriber_ = test_node_->create_subscription<g2_2025_assign1_interfaces_pkg::msg::Student>(
            "student_course_management", 10,
            [this](const g2_2025_assign1_interfaces_pkg::msg::Student::SharedPtr msg) {
                received_student_messages_.push_back(*msg);
            }
        );

        // Publisher to send exam messages
        exam_publisher_ = test_node_->create_publisher<g2_2025_assign1_interfaces_pkg::msg::Exam>(
            "exam_results", 10
        );

        // Mock service server for grade calculator
        grade_calculator_service_ = test_node_->create_service<g2_2025_assign1_interfaces_pkg::srv::Exams>(
            "grade_calculator_service",
            [this](const g2_2025_assign1_interfaces_pkg::srv::Exams::Request::SharedPtr request,
                g2_2025_assign1_interfaces_pkg::srv::Exams::Response::SharedPtr response) {
                    service_requests_.push_back(*request);
                    // Mock calculation - average of grades
                    int sum = 0;
                    for (const auto& grade : request->exam_grades) {
                        sum += grade;
                    }
                    response->result = sum / request->exam_grades.size();
            }
        );

        received_student_messages_.clear();
        service_requests_.clear();
    }

    void TearDown() override {
        final_grade_determinator_.reset();
        fake_db_.reset();
        test_node_.reset();
        rclcpp::shutdown();
    }

    void create_final_grade_determinator() {
        fake_db_ = std::make_unique<assignments::one::MockDatabaseManager>();
        final_grade_determinator_ = std::make_shared<FinalGradeDeterminator>(std::move(fake_db_));
    }

    void spin_some_time(std::chrono::milliseconds duration = 100ms) {
        auto start_time = std::chrono::steady_clock::now();

        while (std::chrono::steady_clock::now() - start_time < duration) {
            rclcpp::spin_some(test_node_);

            if (final_grade_determinator_) {
                rclcpp::spin_some(final_grade_determinator_);
            }

            std::this_thread::sleep_for(10ms);
        }
    }

    std::unique_ptr<assignments::one::MockDatabaseManager> fake_db_;
    std::shared_ptr<rclcpp::Node> test_node_;
    std::shared_ptr<FinalGradeDeterminator> final_grade_determinator_;
    rclcpp::Subscription<g2_2025_assign1_interfaces_pkg::msg::Student>::SharedPtr student_subscriber_;
    rclcpp::Publisher<g2_2025_assign1_interfaces_pkg::msg::Exam>::SharedPtr exam_publisher_;
    rclcpp::Service<g2_2025_assign1_interfaces_pkg::srv::Exams>::SharedPtr grade_calculator_service_;
    std::vector<g2_2025_assign1_interfaces_pkg::msg::Student> received_student_messages_;
    std::vector<g2_2025_assign1_interfaces_pkg::srv::Exams::Request> service_requests_;
};

// ---- TEST CASES ----

TEST_F(FinalGradeDeterminatorTest, ConstructorTest) {
    ASSERT_NO_THROW({
        create_final_grade_determinator();
    });

    ASSERT_NE(final_grade_determinator_, nullptr);
}

TEST_F(FinalGradeDeterminatorTest, ExamCollectionTest) {
    create_final_grade_determinator();
    spin_some_time(500ms);

    const std::string student_name = "Test Student";
    const std::string course_name = "Test Course";
    std::vector<int> grades = { 80, 85, 90, 75, 95 };

    // Send 5 exam results (default collection amount)
    for (const auto& grade : grades) {
        auto msg = std::make_shared<g2_2025_assign1_interfaces_pkg::msg::Exam>();
        msg->student_name = student_name;
        msg->course_name = course_name;
        msg->result = grade;
        msg->timestamp = test_node_->now();

        exam_publisher_->publish(*msg);
        spin_some_time(50ms);
    }

    spin_some_time(1s);

    // Verify service request was made
    ASSERT_FALSE(service_requests_.empty());
    EXPECT_EQ(service_requests_.back().student_name, student_name);
    EXPECT_EQ(service_requests_.back().course_name, course_name);
    EXPECT_EQ(service_requests_.back().exam_grades, grades);

    // Verify student message was published
    ASSERT_FALSE(received_student_messages_.empty());
    EXPECT_EQ(received_student_messages_.back().student_name, student_name);
    EXPECT_EQ(received_student_messages_.back().course_name, course_name);
}

TEST_F(FinalGradeDeterminatorTest, PartialExamCollectionTest) {
    create_final_grade_determinator();
    spin_some_time(500ms);

    // Send only 3 exam results (less than required 5)
    const std::string student_name = "Test Student";
    const std::string course_name = "Test Course";
    std::vector<int> grades = { 80, 85, 90 };

    for (const auto& grade : grades) {
        auto msg = std::make_shared<g2_2025_assign1_interfaces_pkg::msg::Exam>();
        msg->student_name = student_name;
        msg->course_name = course_name;
        msg->result = grade;
        msg->timestamp = test_node_->now();

        exam_publisher_->publish(*msg);
        spin_some_time(50ms);
    }

    spin_some_time(1s);

    // Verify no service request was made yet
    EXPECT_TRUE(service_requests_.empty());
    // Verify no student message was published
    EXPECT_TRUE(received_student_messages_.empty());
}

TEST_F(FinalGradeDeterminatorTest, MultipleStudentsTest) {
    create_final_grade_determinator();
    spin_some_time(500ms);

    std::vector<std::string> students = { "Alice", "Bob" };
    const std::string course_name = "Test Course";
    std::vector<int> grades = { 80, 85, 90, 75, 95 };

    // Send complete set of grades for each student
    for (const auto& student : students) {
        for (const auto& grade : grades) {
            auto msg = std::make_shared<g2_2025_assign1_interfaces_pkg::msg::Exam>();
            msg->student_name = student;
            msg->course_name = course_name;
            msg->result = grade;
            msg->timestamp = test_node_->now();

            exam_publisher_->publish(*msg);
            spin_some_time(50ms);
        }
    }

    spin_some_time(1s);

    // Verify service requests were made for both students
    ASSERT_EQ(service_requests_.size(), 2);
    // Verify student messages were published for both students
    ASSERT_EQ(received_student_messages_.size(), 2);
}
