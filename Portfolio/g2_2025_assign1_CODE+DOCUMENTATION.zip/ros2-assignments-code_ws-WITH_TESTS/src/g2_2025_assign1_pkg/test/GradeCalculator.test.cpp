#include <gtest/gtest.h>
#include <rclcpp/rclcpp.hpp>
#include <thread>
#include <g2_2025_assign1_interfaces_pkg/srv/exams.hpp>
#include "g2_2025_grade_calculator_node/nodes/GradeCalculator.hpp"

using namespace std::chrono_literals;
using assignments::one::g2_2025_grade_calculator_node::GradeCalculator;

class GradeCalculatorTest : public ::testing::Test
{
protected:
    static void SetUpTestSuite() {
        int argc = 0;
        char** argv = nullptr;
        rclcpp::init(argc, argv);
    }

    static void TearDownTestSuite() {
        rclcpp::shutdown();
    }

    void SetUp() override
    {
        // Start GradeCalculator node
        grade_calculator_node_ = std::make_shared<GradeCalculator>();
        executor_ = std::make_shared<rclcpp::executors::SingleThreadedExecutor>();
        executor_->add_node(grade_calculator_node_);

        // Spin in background thread
        spin_thread_ = std::thread([this]() {
            executor_->spin();
        });

        // Create client node
        client_node_ = rclcpp::Node::make_shared("grade_calculator_test_client");
        client_ = client_node_->create_client<g2_2025_assign1_interfaces_pkg::srv::Exams>("grade_calculator_service");
    }

    void TearDown() override
    {
        executor_->cancel();
        if (spin_thread_.joinable()) {
            spin_thread_.join();
        }

        grade_calculator_node_.reset();
        client_.reset();
        client_node_.reset();
    }

    int call_service(const std::string& name, const std::vector<int>& grades)
    {
        if (!client_->wait_for_service(5s)) {
            throw std::runtime_error("Service not available");
        }

        auto request = std::make_shared<g2_2025_assign1_interfaces_pkg::srv::Exams::Request>();
        request->student_name = name;
        request->exam_grades = grades;

        auto future = client_->async_send_request(request);

        if (rclcpp::spin_until_future_complete(client_node_, future) == rclcpp::FutureReturnCode::SUCCESS) {
            return future.get()->result;
        } else {
            throw std::runtime_error("Service call failed");
        }
    }

    std::shared_ptr<rclcpp::executors::SingleThreadedExecutor> executor_;
    std::shared_ptr<GradeCalculator> grade_calculator_node_;
    std::thread spin_thread_;
    rclcpp::Node::SharedPtr client_node_;
    rclcpp::Client<g2_2025_assign1_interfaces_pkg::srv::Exams>::SharedPtr client_;
};

// ---- TEST CASES ----

TEST_F(GradeCalculatorTest, NormalAverage) {
    EXPECT_EQ(call_service("Alice", { 80, 90, 70 }), 80);
}

TEST_F(GradeCalculatorTest, WesselBonus) {
    EXPECT_EQ(call_service("Wessel", { 80, 90, 70 }), 90);
}

TEST_F(GradeCalculatorTest, wesselBonus) {
    EXPECT_EQ(call_service("wessel", { 80, 90, 70 }), 90);
}

TEST_F(GradeCalculatorTest, GradeTooHigh) {
    EXPECT_EQ(call_service("Wessel", { 100, 100, 100 }), 100);
}

TEST_F(GradeCalculatorTest, GradeTooLow) {
    EXPECT_EQ(call_service("Alice", { 0, 0, 0 }), 10);
}
