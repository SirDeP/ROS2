#include <chrono>
#include <memory>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <gtest/gtest.h>

#include "g2_2025_retake_grade_determinator_node/nodes/RetakeGradeDeterminator.hpp"
#include "database/DatabaseManager.hpp"
#include "g2_2025_assign1_interfaces_pkg/msg/exam.hpp"
#include "g2_2025_assign1_interfaces_pkg/msg/student.hpp"
#include "g2_2025_assign1_interfaces_pkg/srv/exams.hpp"
#include "g2_2025_assign1_interfaces_pkg/action/retake.hpp"

#include "mocks/MockDatabaseManager.hpp"

using namespace std::chrono_literals;
using namespace assignments::one::g2_2025_retake_grade_determinator_node;

class RetakeGradeDeterminatorTest : public ::testing::Test {
protected:
    void SetUp() override {
        rclcpp::init(0, nullptr);

        // Create a test node for testing communication
        test_node_ = std::make_shared<rclcpp::Node>("test_node");

        // Create mock database manager
        mock_db_ = std::make_unique<assignments::one::MockDatabaseManager>();
        ptr_mock_db_ = mock_db_.get();

        // Subscriber to capture student management messages
        student_subscriber_ = test_node_->create_subscription<g2_2025_assign1_interfaces_pkg::msg::Student>(
            "student_course_management", 10,
            [this](const g2_2025_assign1_interfaces_pkg::msg::Student::SharedPtr msg) {
                received_student_messages_.push_back(*msg);
            }
        );

        // Publisher to send exam results
        exam_publisher_ = test_node_->create_publisher<g2_2025_assign1_interfaces_pkg::msg::Exam>(
            "exam_results", 10
        );

        // Service server to mock grade calculator
        grade_calculator_service_ = test_node_->create_service<g2_2025_assign1_interfaces_pkg::srv::Exams>(
            "grade_calculator_service",
            [this](const std::shared_ptr<g2_2025_assign1_interfaces_pkg::srv::Exams::Request> request,
                   std::shared_ptr<g2_2025_assign1_interfaces_pkg::srv::Exams::Response> response) {
                service_requests_.push_back(*request);
                response->result = 75;
            }
        );

        // Action client to test retake action server
        retake_action_client_ = rclcpp_action::create_client<g2_2025_assign1_interfaces_pkg::action::Retake>(
            test_node_, "retake_action"
        );

        received_student_messages_.clear();
        service_requests_.clear();
    }

    void TearDown() override {
        retake_grade_determinator_.reset();
        test_node_.reset();
        rclcpp::shutdown();
    }

    void create_retake_grade_determinator() {
        retake_grade_determinator_ = std::make_shared<RetakeGradeDeterminator>(
            std::move(mock_db_)
        );
    }

    void spin_some_time(std::chrono::milliseconds duration = 100ms) {
        auto start_time = std::chrono::steady_clock::now();

        while (std::chrono::steady_clock::now() - start_time < duration) {
            rclcpp::spin_some(test_node_);

            if (retake_grade_determinator_) {
                rclcpp::spin_some(retake_grade_determinator_);
            }

            std::this_thread::sleep_for(10ms);
        }
    }

    std::shared_ptr<rclcpp::Node> test_node_;

    std::unique_ptr<assignments::one::MockDatabaseManager> mock_db_;
    assignments::one::MockDatabaseManager* ptr_mock_db_;
    std::shared_ptr<RetakeGradeDeterminator> retake_grade_determinator_;

    rclcpp::Subscription<g2_2025_assign1_interfaces_pkg::msg::Student>::SharedPtr student_subscriber_;
    rclcpp::Publisher<g2_2025_assign1_interfaces_pkg::msg::Exam>::SharedPtr exam_publisher_;
    rclcpp::Service<g2_2025_assign1_interfaces_pkg::srv::Exams>::SharedPtr grade_calculator_service_;
    rclcpp_action::Client<g2_2025_assign1_interfaces_pkg::action::Retake>::SharedPtr retake_action_client_;

    std::vector<g2_2025_assign1_interfaces_pkg::msg::Student> received_student_messages_;
    std::vector<g2_2025_assign1_interfaces_pkg::srv::Exams::Request> service_requests_;
};

TEST_F(RetakeGradeDeterminatorTest, ConstructorTest) {
    ASSERT_NO_THROW(create_retake_grade_determinator());

    ASSERT_NE(retake_grade_determinator_, nullptr);
}

TEST_F(RetakeGradeDeterminatorTest, PublisherCreationTest) {
    create_retake_grade_determinator();

    bool student_management_topic_found = false;
    auto topic_names_and_types = retake_grade_determinator_->get_topic_names_and_types();

    for (const auto& [ topic_name, topic_types ] : topic_names_and_types) {
        if (topic_name == "/student_course_management") {
            student_management_topic_found = true;
            bool correct_type = false;

            for (const auto& type : topic_types) {
                if (type == "g2_2025_assign1_interfaces_pkg/msg/Student") {
                    correct_type = true;
                    break;
                }
            }

            EXPECT_TRUE(correct_type)
                << "student_course_management topic should have Student message type";
            break;
        }
    }

    EXPECT_TRUE(student_management_topic_found)
        << "student_course_management topic should be published";
}

TEST_F(RetakeGradeDeterminatorTest, SubscriberCreationTest) {
    create_retake_grade_determinator();

    bool exam_results_topic_found = false;
    auto topic_names_and_types = retake_grade_determinator_->get_topic_names_and_types();

    for (const auto& [ topic_name, topic_types ] : topic_names_and_types) {
        if (topic_name == "/exam_results") {
            exam_results_topic_found = true;
            bool correct_type = false;

            for (const auto& type : topic_types) {
                if (type == "g2_2025_assign1_interfaces_pkg/msg/Exam") {
                    correct_type = true;
                    break;
                }
            }

            EXPECT_TRUE(correct_type)
                << "exam_results topic should have Exam message type";
            break;
        }
    }

    EXPECT_TRUE(exam_results_topic_found)
        << "exam_results topic should be subscribed";
}

TEST_F(RetakeGradeDeterminatorTest, ActionServerCreationTest) {
    create_retake_grade_determinator();

    // Allow time for action server to be created
    spin_some_time(500ms);

    // Check if action client can connect to the server
    bool server_available = retake_action_client_->wait_for_action_server(
        std::chrono::seconds(2)
    );

    EXPECT_TRUE(server_available)
        << "Retake action server should be available";
}

TEST_F(RetakeGradeDeterminatorTest, ServiceClientCreationTest) {
    create_retake_grade_determinator();

    auto service_names_and_types = retake_grade_determinator_->get_service_names_and_types();

    bool grade_calculator_service_found = false;
    for (const auto& [ service_name, service_types ] : service_names_and_types) {
        if (service_name == "/grade_calculator_service") {
            grade_calculator_service_found = true;
            break;
        }
    }

    EXPECT_TRUE(grade_calculator_service_found)
        << "grade_calculator_service should be available as client";
}

TEST_F(RetakeGradeDeterminatorTest, ParameterTest) {
    create_retake_grade_determinator();

    auto param = retake_grade_determinator_->get_parameter("grade_collection_amount");
    EXPECT_EQ(param.as_int(), 5)
        << "Default grade_collection_amount should be 5";
}

TEST_F(RetakeGradeDeterminatorTest, ExamResultsIgnoredWhenRetakeNotAllowed) {
    create_retake_grade_determinator();

    auto exam_msg = std::make_shared<g2_2025_assign1_interfaces_pkg::msg::Exam>();
    exam_msg->student_name = "tilmann";
    exam_msg->course_name = "computeren";
    exam_msg->result = 85;

    exam_publisher_->publish(*exam_msg);
    spin_some_time(200ms);

    EXPECT_TRUE(service_requests_.empty())
        << "No service requests should be made when retake not allowed";
}

TEST_F(RetakeGradeDeterminatorTest, RetakeActionGoalAcceptance) {
    create_retake_grade_determinator();

    ASSERT_TRUE(retake_action_client_->wait_for_action_server(std::chrono::seconds(2)));

    auto goal = g2_2025_assign1_interfaces_pkg::action::Retake::Goal();
    goal.student_name = "tilmann";
    goal.course_name = "differentieren";

    bool goal_accepted = false;
    auto send_goal_options = rclcpp_action::Client<g2_2025_assign1_interfaces_pkg::action::Retake>::SendGoalOptions();

    send_goal_options.goal_response_callback =
        [&goal_accepted](
            std::shared_ptr<rclcpp_action::ClientGoalHandle<g2_2025_assign1_interfaces_pkg::action::Retake>> goal_handle
        ) {
            if (goal_handle) {
                goal_accepted = true;
            }
        };

    retake_action_client_->async_send_goal(goal, send_goal_options);
    // Give asynchronous action service time to process
    spin_some_time(500ms);

    EXPECT_TRUE(goal_accepted)
        << "Retake goal should be accepted";
    EXPECT_EQ(received_student_messages_.size(), 1)
        << "Should publish student enrollment message";

    if (!received_student_messages_.empty()) {
        EXPECT_EQ(received_student_messages_[0].student_name, "tilmann");
        EXPECT_EQ(received_student_messages_[0].course_name, "differentieren");
    }
}

// TEST_F(RetakeGradeDeterminatorTest, ExamResultsProcessingDuringRetake) {
//     create_retake_grade_determinator();

//     ASSERT_TRUE(retake_action_client_->wait_for_action_server(std::chrono::seconds(2)));

//     auto goal = g2_2025_assign1_interfaces_pkg::action::Retake::Goal();
//     goal.student_name = "tilmann";
//     goal.course_name = "differentieren";

//     auto send_goal_options = rclcpp_action::Client<g2_2025_assign1_interfaces_pkg::action::Retake>::SendGoalOptions();
//     retake_action_client_->async_send_goal(goal, send_goal_options);
//     spin_some_time(300ms);

//     received_student_messages_.clear();

//     for (int i = 0; i < 5; ++i) {
//         auto exam_msg = std::make_shared<g2_2025_assign1_interfaces_pkg::msg::Exam>();
//         exam_msg->student_name = "tilmann";
//         exam_msg->course_name = "differentieren";
//         exam_msg->result = 70 + i;

//         exam_publisher_->publish(*exam_msg);
//     }

//     spin_some_time(500ms);

//     EXPECT_EQ(service_requests_.size(), 1)
//         << "Should make one service request after collecting required exam results";

//     if (!service_requests_.empty()) {
//         EXPECT_EQ(service_requests_[0].student_name, "tilmann");
//         EXPECT_EQ(service_requests_[0].course_name, "differentieren");
//         EXPECT_EQ(service_requests_[0].exam_grades.size(), 5);
//     }

//     // Should publish final result
//     EXPECT_EQ(received_student_messages_.size(), 1)
//         << "Should publish final student result";

//     // Should store in database with retake flag
//     EXPECT_EQ(ptr_mock_db_->stored_results.size(), 1);
//     if (!ptr_mock_db_->stored_results.empty()) {
//         EXPECT_TRUE(ptr_mock_db_->stored_results[0].is_retake)
//             << "Should store result with retake flag";
//         EXPECT_EQ(ptr_mock_db_->stored_results[0].final_grade, 75);
//     }

//     EXPECT_EQ(ptr_mock_db_->retake_status_updates.size(), 1);
// }

TEST_F(RetakeGradeDeterminatorTest, PartialExamResultsCollection) {
    create_retake_grade_determinator();

    // spin_some_time(500ms);

    ASSERT_TRUE(retake_action_client_->wait_for_action_server(std::chrono::seconds(2)));

    auto goal = g2_2025_assign1_interfaces_pkg::action::Retake::Goal();
    goal.student_name = "tilmann";
    goal.course_name = "differentieren";

    auto send_goal_options = rclcpp_action::Client<g2_2025_assign1_interfaces_pkg::action::Retake>::SendGoalOptions();
    retake_action_client_->async_send_goal(goal, send_goal_options);
    spin_some_time(300ms);

    // Send only 3 out of 5 required exam results
    for (int i = 0; i < 3; ++i) {
        auto exam_msg = std::make_shared<g2_2025_assign1_interfaces_pkg::msg::Exam>();
        exam_msg->student_name = "tilmann";
        exam_msg->course_name = "differentieren";
        exam_msg->result = 65 + i;

        exam_publisher_->publish(*exam_msg);
    }

    spin_some_time(300ms);

    EXPECT_TRUE(service_requests_.empty())
        << "Should not make service request with insufficient exam results";
    EXPECT_TRUE(ptr_mock_db_->stored_results.empty())
        << "Should not store results with insufficient exam results";
}
