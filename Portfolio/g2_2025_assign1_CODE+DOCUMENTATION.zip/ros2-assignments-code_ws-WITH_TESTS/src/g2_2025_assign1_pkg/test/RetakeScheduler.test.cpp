#include <chrono>
#include <memory>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <gtest/gtest.h>

#include "g2_2025_retake_scheduler_node/nodes/RetakeScheduler.hpp"
#include "database/DatabaseManager.hpp"
#include "g2_2025_assign1_interfaces_pkg/action/retake.hpp"

#include "mocks/MockDatabaseManager.hpp"
#include "mocks/MockRetakeActionServer.hpp"

using namespace std::chrono_literals;
using namespace assignments::one::g2_2025_retake_scheduler_node;

class RetakeSchedulerTest : public ::testing::Test {
protected:
    void SetUp() override {
        rclcpp::init(0, nullptr);

        // Create test node and mock action server
        test_node_ = std::make_shared<rclcpp::Node>("test_node");
        mock_action_server_ = std::make_unique<assignments::one::MockRetakeActionServer>(test_node_);

        // Create mock database manager
        mock_db_ = std::make_unique<assignments::one::MockDatabaseManager>();
        mock_db_ptr_ = mock_db_.get();
    }

    void TearDown() override {
        retake_scheduler_.reset();
        mock_action_server_.reset();
        test_node_.reset();
        rclcpp::shutdown();
    }

    void create_retake_scheduler() {
        retake_scheduler_ = std::make_shared<RetakeScheduler>(
            std::move(mock_db_)
        );
    }

    void spin_some_time(std::chrono::milliseconds duration = 100ms) {
        auto start_time = std::chrono::steady_clock::now();

        while (std::chrono::steady_clock::now() - start_time < duration) {
            rclcpp::spin_some(test_node_);

            if (retake_scheduler_) {
                rclcpp::spin_some(retake_scheduler_);
            }

            std::this_thread::sleep_for(10ms);
        }
    }

    std::shared_ptr<rclcpp::Node> test_node_;
    std::shared_ptr<RetakeScheduler> retake_scheduler_;
    std::unique_ptr<assignments::one::MockDatabaseManager> mock_db_;
    assignments::one::MockDatabaseManager* mock_db_ptr_;
    std::unique_ptr<assignments::one::MockRetakeActionServer> mock_action_server_;
};

TEST_F(RetakeSchedulerTest, ConstructorTest) {
    ASSERT_NO_THROW(create_retake_scheduler());

    ASSERT_NE(retake_scheduler_, nullptr);
}

TEST_F(RetakeSchedulerTest, ActionClientCreationTest) {
    create_retake_scheduler();

    bool retake_action_found = false;
    auto service_names_and_types = retake_scheduler_->get_service_names_and_types();

    for (const auto& [ service_name, service_types ] : service_names_and_types) {
        if (service_name == "/retake_action/_action/cancel_goal" ||
            service_name == "/retake_action/_action/get_result" ||
            service_name == "/retake_action/_action/send_goal") {
            retake_action_found = true;
            break;
        }
    }

    EXPECT_TRUE(retake_action_found)
        << "Retake action client services should be available";
}

TEST_F(RetakeSchedulerTest, ParameterTest) {
    create_retake_scheduler();

    // Test default parameter value
    auto param = retake_scheduler_->get_parameter("retake_check_interval_sec");
    EXPECT_EQ(param.as_int(), 120) << "Default retake_check_interval should be 120 seconds";
}

TEST_F(RetakeSchedulerTest, ActionClientAllServicesPresentTest) {
    create_retake_scheduler();

    // Verify all 3 action services are visible on the graph
    auto service_names_and_types = retake_scheduler_->get_service_names_and_types();
    bool has_cancel = false, has_get_result = false, has_send_goal = false;

    for (const auto& [ service_name, _ ] : service_names_and_types) {
        if (service_name == "/retake_action/_action/cancel_goal") has_cancel = true;
        if (service_name == "/retake_action/_action/get_result") has_get_result = true;
        if (service_name == "/retake_action/_action/send_goal") has_send_goal = true;
    }

    EXPECT_TRUE(has_cancel) << "cancel_goal service should be available";
    EXPECT_TRUE(has_get_result) << "get_result service should be available";
    EXPECT_TRUE(has_send_goal) << "send_goal service should be available";
}

TEST_F(RetakeSchedulerTest, ConstructorWithNullDatabaseManager) {
    // Explicitly construct with nullptr to exercise optional DB manager path
    ASSERT_NO_THROW({
        retake_scheduler_ = std::make_shared<RetakeScheduler>(nullptr);
    });
    ASSERT_NE(retake_scheduler_, nullptr);
}

