<img src="https://wessel.gg/static/img/logo-gradient.svg" align="left" width="192px" height="192px"/>
<img align="left" width="0" height="192px" hspace="10"/>

> ros2-assignments

[![MIT License](https://img.shields.io/badge/license-MIT-007EC7.svg?style=flat-square)](/LICENSE)

Assignments made for the first semester of ROS2

<br><br>

## Table of contents

- [System Architecture](#system-architecture)
- [Components](#components)
- [Installation](#installation)

---

## System Architecture

For the complete system architecture see [architecture.md](doc/architecture/architecture.md) located in the `doc/architecture` folder

### Testing

The testing documentation can be found in the [doc/tests](doc/tests/) folder for each node

## Installation

For installation instructions see [Installation.md](doc/installation/installation.md) located in the `doc/installation` folder
