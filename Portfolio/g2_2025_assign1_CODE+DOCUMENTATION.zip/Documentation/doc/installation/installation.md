## Installation

### Prerequisites

- ROS2 Jazzy or newer installed ([ROS2 Installation Guide](https://docs.ros.org/en/jazzy/Installation.html))
- CMake (version 3.8+)
- Python 3.8+
- libtomlplusplus-dev
- libpqxx-dev
- Colcon build tool
- Docker compose

### Clone the Repository

```bash
git clone https://git.wessel.gg/inholland/ros2-assignments.git
cd ros2-assignments
```

### Build the Workspace

```bash
colcon build --packages-select g2_2025_assign1_interfaces_pkg
source install/setup.bash
colcon build --packages-select g2_2025_assign1_pkg
```
Any parameters can be changed before building by editing the `grade_calculator.launch.xml` in the launch folder

### Source the Workspace

```bash
source install/setup.bash
```

### Start the database
```bash
sudo docker-compose up
```
You can configure specific database settings in the `docker-compose.yaml` in the root folder or the `config.toml` file in the `src/` folder

### Start the Grade calculator program
```bash
ros2 launch g2_2025_assign1_pkg grade_calculator.launch.xml
```
To change parameters when using the launch file it will need to be edited in the `src/g2_2025_assign1_pkg/launch` folder. All parameters are already added to this document and thus only the values will need to be changed
