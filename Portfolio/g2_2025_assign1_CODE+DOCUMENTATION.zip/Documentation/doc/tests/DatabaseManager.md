# Database Manager Unit Tests

Unit tests for `DatabaseManager` are implemented in `src/g2_2025_assign1_pkg/test/DatabaseManager.test.cpp` using Google Test and ROS2 test utilities. The tests are designed to work reliably whether a database connection is available or not, focusing on error handling and method behavior validation.

## Test Cases

### 1. ConstructorTest

**Description:** Verifies that DatabaseManager can be created without crashing and proper initialization occurs.

- **Test Action:** Create DatabaseManager instance with ROS2 logger
- **Expected Result:** Instance created successfully without exceptions

### 2. ConnectionStatusTest

**Description:** Tests that the `is_connected()` method returns a valid boolean value.

- **Test Action:** Call `is_connected()` method
- **Expected Result:** Returns either `true` or `false` (no crashes or invalid states)

### 3. QueuePendingCombinationsTest

**Description:** Verifies retrieval of pending student-course combinations that need exam results.

- **Test Action:** Call `queue_pending_combinations()`
- **Expected Result:** Returns valid vector (empty if no database connection, populated if connected)

### 4. StoreExamResultTest

**Description:** Tests exam result storage with graceful handling of connection states.

- **Test Action:**
  - Student: `"TestStudent"`
  - Course: `"TestCourse"`
  - Grade: `85`
- **Expected Result:** Returns `false` if no connection, `true` if connected and successful

### 5. EnrollStudentTest

**Description:** Tests student enrollment into courses.

- **Test Action:**
  - StudentCourse object with test data
- **Expected Result:** Returns `false` if no connection, `true` if connected and successful

### 6. GetFinalGradeTest

**Description:** Tests final grade retrieval for non-existent student-course combinations.

- **Test Action:**
  - Student: `"NonExistentStudent"`
  - Course: `"NonExistentCourse"`
- **Expected Result:** Returns `-1` (no results found or no connection)

### 7. StoreFinalResultTest

**Description:** Tests storing calculated final course results.

- **Test Action:**
  - StudentCourse object
  - Exam count: `3`
  - Final grade: `75`
- **Expected Result:** Returns `false` if no connection, `true` if connected and successful
