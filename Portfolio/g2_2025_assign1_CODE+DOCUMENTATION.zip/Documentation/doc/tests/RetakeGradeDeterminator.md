# RetakeGradeDeterminator Node Unit Tests

This document describes the unit tests for the `RetakeGradeDeterminator` ROS 2 node, as implemented in [`RetakeGradeDeterminator.test.cpp`](../../src/g2_2025_assign1_pkg/test/RetakeGradeDeterminator.test.cpp).

## Test Cases

### 1. ConstructorTest

- **Purpose:**
  Verifies that the `RetakeGradeDeterminator` can be constructed without throwing exceptions.
- **Checks:**
  - The node is created successfully and is not `nullptr`.

### 2. PublisherCreationTest

- **Purpose:**
  Ensures that the node creates a publisher for the `student_course_management` topic.
- **Checks:**
  - The `/student_course_management` topic is present and uses the `Student` message type.

### 3. SubscriberCreationTest

- **Purpose:**
  Ensures that the node subscribes to the `exam_results` topic.
- **Checks:**
  - The `/exam_results` topic is present and uses the `Exam` message type.

### 4. ActionServerCreationTest

- **Purpose:**
  Verifies that the node creates an action server for the `retake_action`.
- **Checks:**
  - The action server is available and can be connected to by an action client.

### 5. ServiceClientCreationTest

- **Purpose:**
  Ensures that the node creates a client for the `grade_calculator_service`.
- **Checks:**
  - The `/grade_calculator_service` is present in the node's service graph.

### 6. ParameterTest

- **Purpose:**
  Confirms that the node's parameters are set to their expected default values.
- **Checks:**
  - The `grade_collection_amount` parameter defaults to `5`.

### 7. ExamResultsIgnoredWhenRetakeNotAllowed

- **Purpose:**
  Ensures that exam results are ignored if a retake is not currently allowed.
- **Checks:**
  - No service requests are made when a retake is not in progress.

### 8. RetakeActionGoalAcceptance

- **Purpose:**
  Verifies that the node accepts retake action goals and publishes the appropriate student enrollment message.
- **Checks:**
  - The retake goal is accepted.
  - A `Student` message is published with the correct student and course names.

### 9. PartialExamResultsCollection

- **Purpose:**
  Ensures that the node does not process or store results if not enough exam results have been collected during a retake.
- **Checks:**
  - No service requests are made.
  - No results are stored in the database if the required number of exam results has not been reached.
