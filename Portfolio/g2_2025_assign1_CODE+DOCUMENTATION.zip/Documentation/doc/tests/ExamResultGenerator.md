# Exam Result Generator Node Unit Tests

Unit tests for `ExamResultGenerator` are implemented in `src/g2_2025_assign1_pkg/test/ExamResultGenerator.test.cpp` using Google Test and ROS2 test utilities. The tests use a test subscriber node to capture published messages and validate node behavior.

## Test Cases

### 1. ConstructorTest

**Description:** Verifies that ExamResultGenerator can be created without crashing and proper initialization occurs.

- **Test Action:** Create ExamResultGenerator node instance
- **Expected Result:**
  - Node created successfully without exceptions
  - Node name set to `"exam_result_generator"`

### 2. PublisherCreationTest

**Description:** Verifies that the `exam_results` topic publisher is properly configured.

- **Test Action:** Check topic names and types after node creation
- **Expected Result:**
  - `/exam_results` topic is published
  - Topic uses `g2_2025_interfaces/msg/Exam` message type

### 3. SubscriberCreationTest

**Description:** Tests that the node subscribes to the `student_course_management` topic with correct message type.

- **Test Action:** Check subscription topics and types
- **Expected Result:**
  - `/student_course_management` topic is subscribed
  - Subscription uses `g2_2025_interfaces/msg/Student` message type

### 4. StudentManagementMessageHandlingTest

**Description:** Tests the node's ability to handle incoming student management messages without crashing.

- **Test Action:**
  - Publish student management message:
    - Student: `"Test Student"`
    - Course: `"Test Course"`
- **Expected Result:** Message processed without crashes

### 5. MultipleStudentMessagesTest

**Description:** Validates handling of multiple rapid student management messages for robustness testing.

- **Test Action:**
  - Send multiple messages with different student-course combinations
  - Students: `["Alice", "Bob", "Charlie"]`
  - Courses: `["Math", "Physics", "Chemistry"]`
- **Expected Result:** All messages processed without crashes or memory issues

### 6. ExamMessageValidationTest

**Description:** Captures and validates published exam result messages for correct content and format.

- **Test Action:** Listen for published exam result messages over 6 seconds
- **Expected Result:**
  - Published grades are within range `[10, 100]`
  - Course names are not empty
  - Message format is correct
