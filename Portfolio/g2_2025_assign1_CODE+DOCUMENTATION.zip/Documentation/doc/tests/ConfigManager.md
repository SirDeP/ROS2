# Config Manager Unit Tests

Unit tests for `ConfigManager` are implemented in `src/g2_2025_assign1_pkg/test/ConfigManager.test.cpp` using Google Test and ROS2 test utilities. The tests use temporary TOML files to validate configuration loading and parsing functionality.

## Test Cases

### 1. ConstructorTest

**Description:** Verifies that ConfigManager can be created with a ROS2 logger without crashing.

- **Test Action:** Create ConfigManager instance with ROS2 logger
- **Expected Result:** Instance created successfully without exceptions

### 2. LoadValidConfigTest

**Description:** Tests loading of valid TOML configuration files with proper parsing.

- **Test Action:**
  - Create temporary TOML file with valid configuration
  - Call `load_config()` with file path
- **Expected Result:**
  - Returns `true`
  - `is_loaded()` returns `true`

### 3. LoadInvalidFileTest

**Description:** Tests error handling when attempting to load non-existent configuration files.

- **Test Action:** Call `load_config()` with non-existent file path
- **Expected Result:**
  - Returns `false`
  - `is_loaded()` returns `false`

### 4. DatabaseConfigParsingTest

**Description:** Tests complete database configuration parsing with all parameters.

- **Test Configuration:**
  ```toml
  [database]
  host = "test_host"
  port = 1234
  dbname = "test_db"
  user = "test_user"
  password = "test_password"
  timeout = 60
  ssl = true

  [database.pool]
  min_connections = 2
  max_connections = 20
  ```
- **Expected Result:** All configuration values parsed correctly with proper types

### 5. DatabaseConfigWithoutPoolTest

**Description:** Tests default values when optional pool section is missing from configuration.

- **Test Configuration:**
  ```toml
  [database]
  host = "localhost"
  port = 5432
  dbname = "grades"
  user = "postgres"
  password = "postgres"
  ```
- **Expected Result:**
  - Main database config parsed correctly
  - Default pool values: `min_connections = 1`, `max_connections = 10`

### 6. GetConfigWithoutLoadingTest

**Description:** Tests behavior when attempting to access configuration before loading any file.

- **Test Action:** Call `get_database_config()` without loading configuration
- **Expected Result:**
  - Returns `std::nullopt`
  - `is_loaded()` returns `false`
