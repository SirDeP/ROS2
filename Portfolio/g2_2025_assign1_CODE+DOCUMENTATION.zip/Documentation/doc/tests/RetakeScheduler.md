# RetakeScheduler Node Unit Tests

Unit tests for `RetakeScheduler` are implemented in `src/g2_2025_assign1_pkg/test/RetakeScheduler.test.cpp`
The unit tests are written using Google Test and ROS 2 test utilities. They utilize clients to interact
with the RetakeScheduler node's services and actions, verifying correct behavior and expected outcomes.

## Test Cases

### 1. ConstructorTest

- **Purpose:**
  Verifies that the `RetakeScheduler` can be constructed without throwing exceptions.
- **Checks:**
  - The node is created successfully and is not `nullptr`.


### 2. ActionClientCreationTest

- **Purpose:**
  Ensures that the `RetakeScheduler` node creates the expected action client services for the retake action.
- **Checks:**
  - At least one of the retake action client services (`/retake_action/_action/cancel_goal`, `/retake_action/_action/get_result`, `/retake_action/_action/send_goal`) is present in the node's service graph.


### 3. ParameterTest

- **Purpose:**
  Confirms that the node's parameters are set to their expected default values.
- **Checks:**
  - The `retake_check_interval_sec` parameter defaults to `120`.


### 4. ActionClientAllServicesPresentTest

- **Purpose:**
  Verifies that all required action client services for the retake action are available.
- **Checks:**
  - The following services are present:
    - `/retake_action/_action/cancel_goal`
    - `/retake_action/_action/get_result`
    - `/retake_action/_action/send_goal`


### 5. ConstructorWithNullDatabaseManager

- **Purpose:**
  Tests the node's behavior when constructed with a `nullptr` database manager.
- **Checks:**
  - The node can be constructed without throwing, even if the database manager is `nullptr`.

