# Final Grade Determintator Node Unit Tests

Unit tests for `FinalGradeDeterminator` are implemented in `src/g2_2025_assign1_pkg/test/FinalGradeDeterminator.test.cpp` using Google Test and ROS2 test utilities. The tests use a mock database manager and a mock grade calculator service to simulate the node's interactions.

## Test Cases

### 1. ConstructorTest

**Description:** Verifies that the node can be constructed without errors.

- **Input:** Construct a `FinalGradeDeterminator` node.
- **Expected Output:** No exceptions are thrown. The node is created successfully.

### 2. ExamCollectionTest

**Description:** Sends the required number of exam results and checks that a grade calculation request is triggered, a student message is published, and the results are stored.

- **Input:**
	- Student: `"Test Student"`
	- Course: `"Test Course"`
	- Grades published: `[80, 85, 90, 75, 95]` (5 exam results, which is the default required amount)
- **Expected Output:**
	- A grade calculation service request is made with the correct student, course, and grades.
	- A student message is published with the correct student and course.
	- The final grade is calculated as the average: (80 + 85 + 90 + 75 + 95) / 5 = 85.

### 3. PartialExamCollectionTest

**Description:** Sends fewer than the required number of exam results and checks that no grade calculation or student message occurs.

- **Input:**
	- Student: `"Test Student"`
	- Course: `"Test Course"`
	- Grades published: `[80, 85, 90]` (only 3 exam results, less than required)
- **Expected Output:**
	- No grade calculation service request is made.
	- No student message is published.

### 4. MultipleStudentsTest

**Description:** Simulates multiple students submitting exam results and verifies that each student triggers independent grade calculation and messaging.

- **Input:**
	- Students: `"Alice"`, `"Bob"`
	- Course: `"Test Course"`
	- Each student receives grades: `[80, 85, 90, 75, 95]` (5 exam results per student)
- **Expected Output:**
	- Two grade calculation service requests are made, one for each student, with the correct grades.
	- Two student messages are published, one for each student.
	- The final grade for each student is calculated as the average: (80 + 85 + 90 + 75 + 95) / 5 = 85.

These tests ensure that the node correctly collects exam results, triggers grade calculation at the right time, publishes the appropriate messages, and interacts with the database as expected.
