# Grade Calculator Node Unit Tests

Unit tests for `GradeCalculator` are implemented in `src/g2_2025_assign1_pkg/test/GradeCalculator.test.cpp` using Google Test and ROS2 test utilities. The tests use a client to call the grade calculation service and verify the results.

## Test Cases

### 1. NormalAverage

**Description:** Verifies that the service returns the average of the provided grades for a normal student name.

- **Input:**
	- Student: `"Alice"`
	- Grades: `[80, 90, 70]`
- **Expected Output:**
	- Result: `80` (average of 80, 90, 70)

### 2. WesselBonus

**Description:** Checks that the student name "Wessel" (case-insensitive) receives a 10-point bonus, and the result is clamped to 100 if necessary.

- **Input:**
	- Student: `"Wessel"`
	- Grades: `[80, 90, 70]`
- **Expected Output:**
	- Result: `90` (average 80 + 10 bonus)

#### 3. wesselBonus

**Description:** Checks that the bonus logic is case-insensitive for the student name "wessel".

- **Input:**
	- Student: `"wessel"`
	- Grades: `[80, 90, 70]`
- **Expected Output:**
	- Result: `90` (average 80 + 10 bonus)

#### 4. GradeTooHigh

**Description:** Ensures that the grade is clamped to a maximum of 100, even after applying the bonus.

- **Input:**
	- Student: `"Wessel"`
	- Grades: `[100, 100, 100]`
- **Expected Output:**
	- Result: `100` (average 100 + 10 bonus, clamped to 100)

#### 5. GradeTooLow

**Description:** Ensures that the grade is clamped to a minimum of 10.

- **Input:**
	- Student: `"Alice"`
	- Grades: `[0, 0, 0]`
- **Expected Output:**
	- Result: `10` (average 0, clamped to 10)

