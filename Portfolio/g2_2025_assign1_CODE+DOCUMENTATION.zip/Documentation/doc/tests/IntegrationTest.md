# Integration Test

Tests the whole integrated system `nodes` connected with each other, with supervisory control and visualization of the database. It tests all major components working together: exam result generation, calculation, database usage, and retake handling.

For validation and verification of database data the databse viewer Dbeaver can be used.

## Test Input Data

**Student Enrollments:**

- `"Wessel", "ROS2"`
- `"Vincent", "ROS2"`
- `"Mohammed", "Differentieren"`
- `"Tilmann", "Differentieren"`

## Test workflow

### 1. Complete Grade Processing Pipeline

**Description**: Tests the full workflow from student enrollment through exam generation to final grade calculation.

**Steps:**

1. **Setup Phase**
   - Clear the database via `docker container prune` or by deleting the tables in dbeaver.
   - Start the databse in a standalone terminal via the command `sudo docker compose up`.
   - Verify database connection.
   - Initialize all system nodes (ExamResultGenerator, FinalGradeDeterminator, GradeCalculator) after building tha package and starting it via the `grade_calculator.launch.xml`.

2. **Exam Generation Phase**
   - ExamResultGenerator publishes Exam messages per student-course pair to table `exam_results` topic.
   - Verify exam results have valid grades (10-100 range).
   - Confirm proper timestamp and student/course name matching.

3. **Grade Collection Phase**
   - FinalGradeDeterminator collects exam results for each student-course combination.
   - Monitor collection count reaches threshold (5 exams per student-course by default) for each student.

4. **Grade Calculation Phase**
   - FinalGradeDeterminator calls GradeCalculator service when threshold reached.
   - Service calculates average grade.

5. **Persistence and Notification Phase**
   - Final grades stored in database with proper timestamps.
   - verify that final_grade_determinator has sent a de-enroll request via student_course_managment to exam_result_generator.
   - exam_result_generator should now prints `removed from queue`.
   - Verify final grade is within valid bounds (10-100) in table `final_course_results`.

**Expected Results:**

```text
Student: Wessel, Course: ROS2
- 5 exam results generated (random grades 10-100)
- Avrage final grade calculated
- Grade stored in database


Student: Vincent, Course: ROS2
- 5 exam results generated (random grades 10-100)
- Avrage final grade calculated
- Grade stored in database


Student: Mohammed, Course: Differentieren
- 5 exam results generated (random grades 10-100)
- Avrage final grade calculated
- Grade stored in database


Student: Tilmann, Course: Differentieren
- 5 exam results generated (random grades 10-100)
- Avrage final grade calculated
- Grade stored in database
```

### 2. Retake Process Integration

**Description**: Tests the retake workflow for students who need to retake exams.

**Setup:**

no setup required, this starts immediately after `final_grade_diterminator` is done after getting the first grades for the students.

**Steps:**

1. **Varify Retake Schedualer is started**
   - Verify in the terminal the schedualer starts the retake process.

2. **Retake Request Phase**
   - RetakeScheduler checks the database for failing students
   - Schedules retake exams with `retake_grade_determinator`

3. **Retake Execution Phase**
   - Generate retake exam results
   - `retake_grade_determinator` processes retake grades and sends them to the calcculator.
   - `retake_grade_determinator` finaly stores the calculated result in the database.

4. **Final Grade Update**
   - Verify grade history preservation
   - Confirm final grade reflects retake performance

**Failing student Expected Retake Results:**

```text
Student: student, Course: course
- 5 exam results generated (random grades 10-100)
- Avrage final grade calculated
- Grade stored in database
- Retake_done checkmark
- Is_retake checkmark
```

## Success Criteria

### Functional Requirements

 All student enrollments processed correctly
 Exam results generated within valid range (10-100)
 Grade collection reaches configured thresholds
 Final grades calculated using proper business logic
 Database persistence works reliably
 Retake process functions correctly when needed
 All ROS2 communication protocols working

## Test Execution Commands

```bash
# 1. enter the ros2 assignment folder
cd /YOUR/PATH/HERE/ros2-assignment

# 2. Build the packages and source the enviroment
colcon build && source install/setup.bash

# 3. clear and Start database (if not running) in stand alone terminal
sudo docker container prune && sudo docker compose up

# 4. Launch all system nodes
ros2 launch g2_2025_assign1_pkg grade_calculator.launch.xml

# 6. Monitor database state
By opening dbeaver and connecting to the database "grades".
Password: postgres
```

## Verification

### Database Validation

- **Student Records**: Verify all students are enrolled correctly
- **Exam Results**: Confirm all exam data is good
- **Final Grades**: Validate calculated grades and timestamps
