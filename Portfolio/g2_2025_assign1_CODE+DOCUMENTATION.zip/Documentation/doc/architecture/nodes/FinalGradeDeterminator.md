# FinalGradeDeterminator (`assignments::one::g2_2025_final_grade_determinator_node`)

## Overview
The `FinalGradeDeterminator` node collects exam results for student-course combinations, triggers grade calculation when enough results are gathered, and stores final grades in the database. It interacts with ROS2 publishers, subscribers, and service clients to manage the grading workflow.

#### Implementation Details

**Parameters**

- **`grade_collection_amount`** (int, default: 5): Number of exam results required before triggering grade calculation for a student-course combination.

**Constructor**
```cpp
FinalGradeDeterminator()
```
- Initializes ROS2 node with name `g2_2025_final_grade_determinator_node`
- Declares and retrieves `grade_collection_amount` parameter
- Sets up `DatabaseManager`
- Creates publisher for student course management
- Subscribes to exam results topic
- Initializes service client for grade calculation

**Core Functions**

**`void exam_results_callback(const g2_2025_assign1_interfaces_pkg::msg::Exam::SharedPtr msg)`**
- Updates internal map with received exam result for student-course combo
- Checks if enough results have been collected
- Triggers grade calculation request when threshold is met

**`void grade_calculator_request(StudentCourse combo)`**
- Waits for grade calculator service to be available
- Sends async request with collected exam grades for the student-course combination
- Uses callback to handle service response

**`void grade_calculator_response(rclcpp::Client<g2_2025_assign1_interfaces_pkg::srv::Exams>::SharedFuture future, StudentCourse studentCourseCombo)`**
- Verifies database connection
- Publishes final student message to ROS2 topic
- Logs final grade information
- Stores final course result in database
