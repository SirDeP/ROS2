# RetakeScheduler (`assignments::one::g2_2025_retake_scheduler_node`)

## Overview
The `RetakeScheduler` node automatically identifies students who have failed courses and schedules retake exams for them. It periodically queries the database for failing students and sends retake action requests to the `RetakeGradeDeterminator` node to initiate the retake process.

#### Implementation Details

**Parameters**

- **`retake_check_interval_sec`** (int, default: 120): Time interval in seconds between checks for failing students requiring retakes.

**Constructor**
```cpp
RetakeScheduler(std::unique_ptr<DatabaseManager> db_manager = nullptr)
```
- Initializes ROS2 node with name `g2_2025_retake_scheduler_node`
- Sets up `DatabaseManager` (optional injection for testing)
- Creates ROS2 action client for retake action communication
- Initializes wall timer for periodic failing student checks

**Core Functions**

**`void check_failing_students()`**
- Timer callback function executed periodically based on `retake_check_interval_sec`
- Queries database for all failed course results
- Iterates through failing students and initiates retake requests

**`void send_retake_request(StudentCourse student_course_combo)`**
- Creates retake action goal with student and course information
- Sends asynchronous retake goal to `RetakeGradeDeterminator`

**`void cancel_retake_request()`**
- Cancels all active retake goals
- Provides emergency stop functionality for retake processing

**Action Client Callbacks**

**`void request_response_callback(const rclcpp_action::ClientGoalHandle<RetakeAction>::SharedPtr &goal_handle)`**
- Handles retake action server responses
- Logs goal acceptance or rejection status
- Provides feedback on retake request processing state

**`void request_result_callback(const rclcpp_action::ClientGoalHandle<RetakeAction>::WrappedResult &result)`**
- Processes final retake action results
- Logs appropriate messages based on retake completion status

**`void request_feedback_callback(rclcpp_action::ClientGoalHandle<RetakeAction>::SharedPtr goal_handle, const std::shared_ptr<const RetakeAction::Feedback> feedback)`**
