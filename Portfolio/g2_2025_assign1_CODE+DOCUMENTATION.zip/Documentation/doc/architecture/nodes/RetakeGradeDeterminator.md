# RetakeGradeDeterminator (`assignments::one::g2_2025_retake_grade_determinator_node`)

## Overview
The `RetakeGradeDeterminator` node handles the processing of retake exams for students who have
failed courses. It provides a ROS2 action server that accepts retake requests, manages exam result
collection for retake scenarios, and coordinates with the grade calculator service to determine
final retake grades.

#### Implementation Details

**Parameters**

- **`grade_collection_amount`** (int, default: 5): Number of exam results required before triggering grade calculation for a retake student-course combination.

**Constructor**
```cpp
RetakeGradeDeterminator(std::unique_ptr<DatabaseManager> db_manager = nullptr)
```
- Initializes ROS2 node with name `g2_2025_retake_grade_determinator_node`
- Sets up `DatabaseManager` (optional injection for testing)
- Creates publisher for student course management
- Subscribes to exam results topic with retake-specific callback
- Initializes service client for grade calculation
- Creates ROS2 action server for retake requests with reentrant callback group

**Core Functions**

**`void exam_results_callback(const g2_2025_assign1_interfaces_pkg::msg::Exam::SharedPtr msg)`**
- Only processes exam results when `retake_allowed_` flag is true
- Triggers grade calculation request when threshold is met

**`void grade_calculator_request(StudentCourse combo)`**
- Waits for grade calculator service to be available
- Sends async request with collected retake exam grades

**`void grade_calculator_response(rclcpp::Client<g2_2025_assign1_interfaces_pkg::srv::Exams>::SharedFuture future, StudentCourse studentCourseCombo)`**
- Clears collected exam data from internal map
- Updates retake status in database for the student-course combination
- Publishes final student message to ROS2 topic with timestamp
- Stores final course result in database with retake flag set to true

**Action Server Callbacks**

**`rclcpp_action::GoalResponse goal_callback(const rclcpp_action::GoalUUID& uuid, std::shared_ptr<const g2_2025_assign1_interfaces_pkg::action::Retake::Goal> goal)`**
- Accepts retake goal requests for specific student-course combinations
- Logs received retake requests with student and course information
- Returns `ACCEPT_AND_EXECUTE` for all valid requests

**`rclcpp_action::CancelResponse cancel_callback(const std::shared_ptr<rclcpp_action::ServerGoalHandle<g2_2025_assign1_interfaces_pkg::action::Retake>> goal_handle)`**
- Handles retake action cancellation requests
- Returns `ACCEPT` for all cancellation requests

**`void spawn_callback_thread(const std::shared_ptr<rclcpp_action::ServerGoalHandle<g2_2025_assign1_interfaces_pkg::action::Retake>> goal_handle)`**
- Creates detached thread for asynchronous retake action execution
- Ensures non-blocking retake processing

**`void async_execute_callback_thread(const std::shared_ptr<rclcpp_action::ServerGoalHandle<g2_2025_assign1_interfaces_pkg::action::Retake>> goal_handle)`**
- Enables retake exam processing by setting `retake_allowed_` flag
- Publishes student enrollment message to trigger exam generation
- Creates and returns successful action result
