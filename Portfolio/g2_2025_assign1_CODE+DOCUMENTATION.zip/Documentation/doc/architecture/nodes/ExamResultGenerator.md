# ExamResultGenerator (`assignments::one::g2_2025_exam_result_generator_node`)

## Overview
The `ExamResultGenerator` is the core node responsible for simulating exam result generation.
It maintains a queue of student-course combinations that need exam results, generates random
grades, and publishes them to the system.

#### Implementation Details

**Parameters**

- **`delay_between_grades_ms`** (int, default: 2000): Delay (in milliseconds) between generated grades.

**Constructor**
```cpp
ExamResultGenerator()
```
- Initializes ROS2 node with name `g2_2025_exam_result_generator_node`
- Sets up random number generation infrastructure
- Creates DatabaseManager instance with node logger
- Establishes ROS2 publishers, subscribers, and timers
- Loads initial pending combinations from database

**Core Functions**

**`void queue_pending_combinations()`**
- Gets all student-course combinations needing exam results
- Populates operations queue from database
- Called at initialization and when database state changes

**`void generate_random_result()`**
- Main exam result generation executed by timer
- Selects random student-course combination from queue
- Stores result in database and publishes to ROS2 topic

**`void student_management_callback(const g2_2025_assign1_interfaces_pkg::msg::Student::SharedPtr msg)`**
- Toggles combinations in/out of processing queue
- Updates database with new enrollments

**`void add_student_course_combination(const StudentCourse& sc)`**
- Enrolls student into course via database
- Adds combination to processing queue
