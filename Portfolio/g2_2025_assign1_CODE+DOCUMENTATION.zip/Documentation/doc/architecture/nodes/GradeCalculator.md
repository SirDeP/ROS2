# GradeCalculator (`assignments::one::g2_2025_grade_calculator_node::GradeCalculator`)

## Overview
The `GradeCalculator` node provides a ROS2 service for calculating student exam grades. It processes exam scores, applies custom logic for specific student names, and ensures grade results are within valid bounds.

#### Implementation Details

**Constructor**
```cpp
GradeCalculator()
```
- Initializes ROS2 node with name `g2_2025_grade_calculator_node`
- Creates a ROS2 service server for `grade_calculator_service`
- Binds the service callback to handle grade calculation requests
- Logs service startup

**Core Functions**

**`void grade_calculator_callback(const Exams::Request::SharedPtr request, const Exams::Response::SharedPtr response)`**
- Checks if exam grades are provided
- Calculates the total and average of exam grades
- Converts student name to lowercase for comparison
- Adds a bonus of 10 points if the student name is "wessel"
- Ensures the final grade is clamped between 10 and 100
- Sends the calculated grade back through the service response
