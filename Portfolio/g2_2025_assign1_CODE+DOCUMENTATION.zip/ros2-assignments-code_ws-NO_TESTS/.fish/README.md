# Exported Fish Environment: ros2-assignments

This directory contains a self-contained Fish shell environment that can be used
without requiring the original Fish configuration.

## Files Structure
```
.fish/
├── activate.fish    # Main environment configuration
└── README.md        # This file
```

## Usage

### Automatic Activation (Recommended)
The environment will automatically activate when you `cd` into this directory
if your Fish shell is configured with the auto-activation feature that checks
for `.fish/activate.fish`.

### Manual Activation
To manually activate the environment, run from the project root:
```bash
source ./.fish/activate.fish
```

### Deactivation
To deactivate the environment, run:
```bash
env deactivate
```

Or simply `cd` to a different directory if using auto-activation.

## What This Environment Provides

- Custom prompt showing the environment name
- Environment-specific aliases and functions
- Custom environment variables
- Automatic cleanup when deactivated

## Requirements

- Fish shell
- If this is a ROS2 environment: `bass` plugin (`fisher install edc/bass`)

## Sharing

This environment is completely self-contained. You can:
1. Copy this directory to another machine
2. Share it with other Fish shell users
3. Version control it with your project (add .fish/ to your repo)

The environment will work on any system with Fish shell, regardless of whether
they have the original environment management system installed.

## Auto-activation Setup

To enable auto-activation for .fish/activate.fish, add this to your Fish config.fish:
```fish
function check_and_source_activate
  if test -f (pwd)/.fish/activate.fish
    source (pwd)/.fish/activate.fish
  elif test -f (pwd)/activate.fish
    source (pwd)/activate.fish
  end
end

function cd
  builtin cd $argv && check_and_source_activate
end
```