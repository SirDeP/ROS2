# Self-contained environment: ros2-assignments
# Exported on: Tue Sep 23 10:20:42 AM CEST 2025
# Original environment from: /home/wessel/.config/fish/environments/configs/ros2-assignments

# ROS2 development environment (requires distrobox)
# Environment: ros2-assignments

# First check if running inside distrobox
if not test -f /run/.containerenv; and test -z "$CONTAINER_ID"
    echo (set_color red)"This ROS2 environment should only be run inside a distrobox container"(set_color normal)
    return 1
end

# Check if a previous initialization has occurred
if test -n "$__ENV_INITIALIZED"
    echo (set_color yellow)"Environment already initialized"(set_color normal)
    return 0
end

# Mark as initialized (only after distrobox check passes)
set -gx __ENV_INITIALIZED "1"
set -gx CURRENT_ENV "ros2-assignments"
# Source ROS2 setup files using bass
if type -q bass
    bass source /opt/ros/jazzy/setup.bash
    if test -f ./install/setup.bash
        bass source ./install/setup.bash
    end
else
    echo (set_color red)"Error: bass is required for ROS2 environment. Install with: fisher install edc/bass"(set_color normal)
    return 1
end

# Set environment variable for the prompt prefix
set -gx ROS2_ACTIVE 1

# Save the original prompt function if it exists
# Only save if we don't already have a backup or if current prompt is not from an environment
if not functions -q __env_orig_prompt
    if functions -q fish_prompt
        functions -c fish_prompt __env_orig_prompt
    else
        function __env_orig_prompt
            echo -n (whoami)'@'(prompt_hostname)' '(set_color $fish_color_cwd)(prompt_pwd)(set_color normal)'> '
        end
    end
else
    # If we already have a backup, we're switching environments
    # No need to create a new backup
end

# Define new prompt with ROS2 prefix
function fish_prompt
    echo -n (set_color magenta)'(ros2-assignments)'(set_color normal)' '
    __env_orig_prompt
end

# ROS2 aliases and functions
alias cb="colcon build"
alias cbs="colcon build --symlink-install"
alias cbt="colcon build --packages-select"
alias ct="colcon test"
alias ctr="colcon test-result"

echo (set_color green)"Activated ROS2 environment: ros2-assignments"(set_color normal)

# Custom deactivation function
function __env_custom_deactivate
    # Remove ROS2-specific variables and aliases
    set -e ROS2_ACTIVE
    functions -e cb cbs cbt ct ctr 2>/dev/null

    echo (set_color blue)"ROS2 environment cleanup completed"(set_color normal)
end