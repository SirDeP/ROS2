/* DatabaseConfig.hpp
 * Database configuration structure for the exam result generator
 *
 * Reviewed by: <x>
 * Changelog:
 * [23-09-2025] Wessel T: Create initial configuration structure
 */
#pragma once

#include <string>

namespace assignments::one {

struct DatabaseConfig {
    std::string host;
    int port;
    std::string dbname;
    std::string user;
    std::string password;
    int timeout;
    bool ssl;

    // Pool settings
    int min_connections;
    int max_connections;

    std::string to_connection_string() const {
        std::string conn_str =
            "host=" + host +
            " port=" + std::to_string(port) +
            " dbname=" + dbname +
            " user=" + user +
            " password=" + password +
            " connect_timeout=" + std::to_string(timeout);

        if (ssl) {
            conn_str += " sslmode=require";
        } else {
            conn_str += " sslmode=disable";
        }

        return conn_str;
    }
};

} // namespace assignments::one
