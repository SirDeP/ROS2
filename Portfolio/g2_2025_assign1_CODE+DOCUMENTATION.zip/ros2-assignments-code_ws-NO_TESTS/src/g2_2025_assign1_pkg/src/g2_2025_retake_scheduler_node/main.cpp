/* node_template.cpp
 * Action server node template for ROS2
 *
 * Node description:
 * Template action server that demonstrates action server implementation
 * with goal handling, feedback publishing, and cancellation support
 *
 * Reviewed by: <x>
 * Changelog:
 * [04-09-2025] Wessel T: Implement template
 */

#include <cstdlib>

#include "rclcpp/rclcpp.hpp"
#include "nodes/RetakeScheduler.hpp"



int main(int argc,char *argv[]) {
    rclcpp::init(argc,argv);

    auto node = std::make_shared<assignments::one::g2_2025_retake_scheduler_node::RetakeScheduler>();

    rclcpp::spin(node);
    rclcpp::shutdown();

    return 0;
}
