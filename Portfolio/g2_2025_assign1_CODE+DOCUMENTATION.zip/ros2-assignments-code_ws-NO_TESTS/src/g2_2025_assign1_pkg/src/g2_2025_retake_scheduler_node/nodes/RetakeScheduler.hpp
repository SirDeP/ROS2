#pragma once

#include <memory>
#include <string>
#include <vector>
#include <chrono>

#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "g2_2025_assign1_interfaces_pkg/action/retake.hpp"

#include "database/DatabaseManager.hpp"
#include "database/StudentCourse.hpp"

namespace assignments::one::g2_2025_retake_scheduler_node {

class RetakeScheduler : public rclcpp::Node {
public:
    RetakeScheduler(std::unique_ptr<DatabaseManager> db_manager = nullptr);

private:
    rclcpp::TimerBase::SharedPtr timer_;
    std::unique_ptr<DatabaseManager> db_manager_;

    using RetakeAction = g2_2025_assign1_interfaces_pkg::action::Retake;
    rclcpp_action::Client<RetakeAction>::SharedPtr retake_action_client_;

    int retake_check_interval_;

    void send_retake_request(StudentCourse combo);
    void cancel_retake_request();

    void check_failing_students();

    void request_response_callback(
        const rclcpp_action::ClientGoalHandle<RetakeAction>::SharedPtr &goal_handle
    );

    void request_result_callback(
        const rclcpp_action::ClientGoalHandle<RetakeAction>::WrappedResult &result
    );

    void request_feedback_callback(
        rclcpp_action::ClientGoalHandle<RetakeAction>::SharedPtr goal_handle,
        const std::shared_ptr<const RetakeAction::Feedback> feedback
    );
};

} // namespace assignments::one::g2_2025_retake_scheduler_node
