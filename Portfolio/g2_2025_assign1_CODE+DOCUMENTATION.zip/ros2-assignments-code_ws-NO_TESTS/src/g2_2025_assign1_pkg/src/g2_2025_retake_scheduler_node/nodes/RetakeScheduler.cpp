#include "RetakeScheduler.hpp"

namespace assignments::one::g2_2025_retake_scheduler_node {

RetakeScheduler::RetakeScheduler(std::unique_ptr<DatabaseManager> db_manager) : Node("g2_2025_retake_scheduler_node") {
    this->declare_parameter("retake_check_interval_sec", 120); // Default to 120 seconds
    retake_check_interval_ = this->get_parameter("retake_check_interval_sec").as_int();

    // Make db_manager optional for testing purposes
    if (db_manager) {
        db_manager_ = std::move(db_manager);
    } else {
        db_manager_ = std::make_unique<DatabaseManager>(this->get_logger());
    }
    // Create action client to communicate with RetakeGradeDeterminator
    retake_action_client_ = rclcpp_action::create_client<RetakeAction>(this, "retake_action");

    // Check for failing students periodically
    timer_ = this->create_wall_timer(
        std::chrono::seconds(retake_check_interval_),
        std::bind(&RetakeScheduler::check_failing_students, this)
    );
}

void RetakeScheduler::check_failing_students() {
    RCLCPP_INFO(this->get_logger(), "Checking for failing students...");

    std::vector<StudentCourse> failing_students = db_manager_->get_failed_course_results();
    if (failing_students.empty()) {
        RCLCPP_INFO(this->get_logger(), "No failing students found.");
        return;
    }

    for (const auto& student_course_combo : failing_students) {
        send_retake_request(student_course_combo);
    }
}

void RetakeScheduler::send_retake_request(StudentCourse student_course_combo) {
    if (!retake_action_client_->wait_for_action_server(std::chrono::seconds(5))) {
        RCLCPP_ERROR(this->get_logger(), "Retake action server not available after waiting");
        return;
    }

    auto goal_msg = RetakeAction::Goal();
    goal_msg.student_name = student_course_combo.student_name;
    goal_msg.course_name = student_course_combo.course_name;

    RCLCPP_INFO(this->get_logger(), "Sending retake request for %s // %s", student_course_combo.student_name.c_str(), student_course_combo.course_name.c_str());

    auto send_goal_options = rclcpp_action::Client<RetakeAction>::SendGoalOptions();
    send_goal_options.goal_response_callback = std::bind(&RetakeScheduler::request_response_callback, this, std::placeholders::_1);
    send_goal_options.result_callback = std::bind(&RetakeScheduler::request_result_callback, this, std::placeholders::_1);
    send_goal_options.feedback_callback = std::bind(&RetakeScheduler::request_feedback_callback, this, std::placeholders::_1, std::placeholders::_2);

    retake_action_client_->async_send_goal(goal_msg, send_goal_options);

    RCLCPP_INFO(this->get_logger(), "Retake request sent.");
}

void RetakeScheduler::cancel_retake_request() {
    retake_action_client_->async_cancel_all_goals();
    RCLCPP_INFO(this->get_logger(), "Sent cancel request for all retake goals.");
}

void RetakeScheduler::request_response_callback(
    const rclcpp_action::ClientGoalHandle<RetakeAction>::SharedPtr &goal_handle
) {
    if (!goal_handle) {
        RCLCPP_ERROR(this->get_logger(), "Retake goal was rejected by server");
    } else {
        RCLCPP_INFO(this->get_logger(), "Retake goal accepted by server, waiting for result");
    }
}

void RetakeScheduler::request_result_callback(
    const rclcpp_action::ClientGoalHandle<RetakeAction>::WrappedResult &result
) {
    switch (result.code) {
        case rclcpp_action::ResultCode::SUCCEEDED:
            RCLCPP_INFO(this->get_logger(), "Retake goal succeeded");
            break;
        case rclcpp_action::ResultCode::ABORTED:
            RCLCPP_ERROR(this->get_logger(), "Retake goal was aborted");
            return;
        case rclcpp_action::ResultCode::CANCELED:
            RCLCPP_ERROR(this->get_logger(), "Retake goal was canceled");
            return;
        default:
            RCLCPP_ERROR(this->get_logger(), "Unknown result code");
            return;
    }
    RCLCPP_INFO(this->get_logger(), "Retake result received: %.2f", result.result->result);
}

void RetakeScheduler::request_feedback_callback(
    rclcpp_action::ClientGoalHandle<RetakeAction>::SharedPtr goal_handle,
    const std::shared_ptr<const RetakeAction::Feedback> feedback
) {
    (void)goal_handle;
    RCLCPP_INFO(this->get_logger(), "Received feedback: %s", feedback->status.c_str());
}

} // namespace assignments::one::g2_2025_retake_scheduler_node
