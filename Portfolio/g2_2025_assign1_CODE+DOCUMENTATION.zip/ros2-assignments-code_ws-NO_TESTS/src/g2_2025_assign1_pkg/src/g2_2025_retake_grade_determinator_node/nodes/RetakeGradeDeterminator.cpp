#include "RetakeGradeDeterminator.hpp"

namespace assignments::one::g2_2025_retake_grade_determinator_node {

RetakeGradeDeterminator::RetakeGradeDeterminator(std::unique_ptr<DatabaseManager> db_manager) : Node("g2_2025_retake_grade_determinator_node") {
    this->declare_parameter("grade_collection_amount", 5);
    grade_collection_amount_ = this->get_parameter("grade_collection_amount").as_int();

    // Make db_manager optional for testing purposes
    if (db_manager) {
        db_manager_ = std::move(db_manager);
    } else {
        db_manager_ = std::make_unique<DatabaseManager>(this->get_logger());
    }
    // Create publisher for exam results
    student_publisher_ = this->create_publisher<g2_2025_assign1_interfaces_pkg::msg::Student>(
        "student_course_management", 10
    );

    // Create subscriber for adding/removing student/course combinations
    exam_subscriber_ = this->create_subscription<g2_2025_assign1_interfaces_pkg::msg::Exam>(
        "exam_results", 10,
        std::bind(
            &RetakeGradeDeterminator::exam_results_callback,
            this,
            std::placeholders::_1
        )
    );

    exam_service_client_ = this->create_client<g2_2025_assign1_interfaces_pkg::srv::Exams>("grade_calculator_service");

    // Create action server for retake requests
    callback_group_ = this->create_callback_group(rclcpp::CallbackGroupType::Reentrant);
    retake_actionserver_ = rclcpp_action::create_server<g2_2025_assign1_interfaces_pkg::action::Retake>(
        this,
        "retake_action",
        std::bind(&RetakeGradeDeterminator::goal_callback, this, std::placeholders::_1, std::placeholders::_2),
        std::bind(&RetakeGradeDeterminator::cancel_callback, this, std::placeholders::_1),
        std::bind(&RetakeGradeDeterminator::spawn_callback_thread, this, std::placeholders::_1),
        rcl_action_server_get_default_options(),
        callback_group_
    );

    RCLCPP_INFO(this->get_logger(), "Action server has been started.");
}

void RetakeGradeDeterminator::exam_results_callback(
    const g2_2025_assign1_interfaces_pkg::msg::Exam::SharedPtr msg
) {
    if (retake_allowed_) {
        student_course_combo_.student_name = msg->student_name;
        student_course_combo_.course_name = msg->course_name;

        data_map_[student_course_combo_].push_back(msg->result);

        auto grade_collection_as_ulong = static_cast<unsigned long>(grade_collection_amount_);
        if (data_map_[student_course_combo_].size() == grade_collection_as_ulong) {
            RCLCPP_INFO(this->get_logger(),
                "%s // %s: results sent to calculator",
                msg->student_name.c_str(), msg->course_name.c_str()
            );
            grade_calculator_request(student_course_combo_);
        }
    }
}

void RetakeGradeDeterminator::grade_calculator_request(StudentCourse combo) {
    if (!exam_service_client_->wait_for_service(std::chrono::seconds(1))) {
        RCLCPP_WARN(this->get_logger(), "Service not available");
        return;
    }

    auto request = std::make_shared<g2_2025_assign1_interfaces_pkg::srv::Exams::Request>();
    request->course_name = combo.course_name;
    request->student_name = combo.student_name;
    request->exam_grades = data_map_[combo];

    // Callback is used due to ros2 not liking passing multiple arguments in async calls
    auto callback = [this, combo](rclcpp::Client<g2_2025_assign1_interfaces_pkg::srv::Exams>::SharedFuture future) {
        this->grade_calculator_response(future, combo);
        };
    exam_service_client_->async_send_request(request, callback);
}

void RetakeGradeDeterminator::grade_calculator_response(
    rclcpp::Client<g2_2025_assign1_interfaces_pkg::srv::Exams>::SharedFuture future,
    StudentCourse studentCourseCombo
) {
    if (!db_manager_ || !db_manager_->is_connected()) {
        RCLCPP_WARN(this->get_logger(), "no database connection");
        return;
    }
    data_map_[studentCourseCombo].clear();
    db_manager_->update_retake_status(studentCourseCombo);

    auto response = future.get();

    auto student_message = g2_2025_assign1_interfaces_pkg::msg::Student();
    student_message.student_name = studentCourseCombo.student_name;
    student_message.course_name = studentCourseCombo.course_name;
    student_message.timestamp = this->now();
    student_publisher_->publish(student_message);

    RCLCPP_INFO(this->get_logger(),
        "%s // %s is %d",
        studentCourseCombo.student_name.c_str(), studentCourseCombo.course_name.c_str(), response->result
    );

    db_manager_->store_final_course_result(
        studentCourseCombo,
        grade_collection_amount_,
        response->result,
        true
    );
}

rclcpp_action::GoalResponse RetakeGradeDeterminator::goal_callback(
    const rclcpp_action::GoalUUID& uuid,
    std::shared_ptr<const g2_2025_assign1_interfaces_pkg::action::Retake::Goal> goal
) {
    (void)uuid;
    RCLCPP_INFO(this->get_logger(),
        "Received retake goal request for student: %s, course: %s",
        goal->student_name.c_str(), goal->course_name.c_str());

    RCLCPP_INFO(this->get_logger(), "Retake goal accepted");
    return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE;
}

rclcpp_action::CancelResponse RetakeGradeDeterminator::cancel_callback(
    const std::shared_ptr<rclcpp_action::ServerGoalHandle<g2_2025_assign1_interfaces_pkg::action::Retake>> goal_handle
) {
    (void)goal_handle;
    RCLCPP_INFO(this->get_logger(), "Received request to cancel retake goal");
    return rclcpp_action::CancelResponse::ACCEPT;
}

void RetakeGradeDeterminator::spawn_callback_thread(
    const std::shared_ptr<rclcpp_action::ServerGoalHandle<g2_2025_assign1_interfaces_pkg::action::Retake>> goal_handle
) { // Spawn a new thread to prevent blocking the executor
    std::thread{std::bind(&RetakeGradeDeterminator::async_execute_callback_thread, this, std::placeholders::_1), goal_handle}.detach();
}

void RetakeGradeDeterminator::async_execute_callback_thread(
    const std::shared_ptr<rclcpp_action::ServerGoalHandle<g2_2025_assign1_interfaces_pkg::action::Retake>> goal_handle
) {
    retake_allowed_ = true;
    RCLCPP_INFO(this->get_logger(), "Executing retake action for %s // %s", goal_handle->get_goal()->student_name.c_str(), goal_handle->get_goal()->course_name.c_str());

    auto student_message = g2_2025_assign1_interfaces_pkg::msg::Student();
    student_message.student_name = goal_handle->get_goal()->student_name;
    student_message.course_name = goal_handle->get_goal()->course_name;
    student_message.timestamp = this->now();
    student_publisher_->publish(student_message);

    auto result = std::make_shared<g2_2025_assign1_interfaces_pkg::action::Retake::Result>();
    result->result = 0.0;
    goal_handle->succeed(result);
}

} // namespace assignments::one::g2_2025_retake_grade_determinator_node
