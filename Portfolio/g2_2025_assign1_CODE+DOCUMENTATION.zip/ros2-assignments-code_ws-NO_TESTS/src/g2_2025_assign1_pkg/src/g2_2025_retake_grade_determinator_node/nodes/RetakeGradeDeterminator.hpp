#pragma once

#include <memory>
#include <string>
#include <random>
#include <vector>
#include <chrono>

#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"

#include "g2_2025_assign1_interfaces_pkg/msg/exam.hpp"
#include "g2_2025_assign1_interfaces_pkg/msg/student.hpp"
#include "g2_2025_assign1_interfaces_pkg/srv/exams.hpp"
#include "g2_2025_assign1_interfaces_pkg/action/retake.hpp"

#include "database/DatabaseManager.hpp"
#include "database/StudentCourse.hpp"

namespace assignments::one::g2_2025_retake_grade_determinator_node {

class RetakeGradeDeterminator : public rclcpp::Node {
public:
    RetakeGradeDeterminator(std::unique_ptr<DatabaseManager> db_manager = nullptr);
private:
    rclcpp::Subscription<g2_2025_assign1_interfaces_pkg::msg::Exam>::SharedPtr exam_subscriber_;
    rclcpp::Publisher<g2_2025_assign1_interfaces_pkg::msg::Student>::SharedPtr student_publisher_;

    rclcpp_action::Server<g2_2025_assign1_interfaces_pkg::action::Retake>::SharedPtr retake_actionserver_;
    rclcpp::CallbackGroup::SharedPtr callback_group_;

    rclcpp::Client<g2_2025_assign1_interfaces_pkg::srv::Exams>::SharedPtr exam_service_client_;

    std::unique_ptr<DatabaseManager> db_manager_;

    StudentCourse student_course_combo_;
    StudentCourseResultMap data_map_;

    // Params
    int grade_collection_amount_;
    bool retake_allowed_ = false;

    void grade_calculator_request(StudentCourse combo);
    void exam_results_callback(const g2_2025_assign1_interfaces_pkg::msg::Exam::SharedPtr msg);
    void grade_calculator_response(
        rclcpp::Client<g2_2025_assign1_interfaces_pkg::srv::Exams>::SharedFuture future,
        StudentCourse studentCourseCombo
    );

    rclcpp_action::GoalResponse goal_callback(
        const rclcpp_action::GoalUUID & uuid,
        std::shared_ptr<const g2_2025_assign1_interfaces_pkg::action::Retake::Goal> goal);

    rclcpp_action::CancelResponse cancel_callback(
        const std::shared_ptr<rclcpp_action::ServerGoalHandle<g2_2025_assign1_interfaces_pkg::action::Retake>> goal_handle);

    void spawn_callback_thread(const std::shared_ptr<rclcpp_action::ServerGoalHandle<g2_2025_assign1_interfaces_pkg::action::Retake>> goal_handle);
    void async_execute_callback_thread(const std::shared_ptr<rclcpp_action::ServerGoalHandle<g2_2025_assign1_interfaces_pkg::action::Retake>> goal_handle);
};

} // namespace assignments::one::g2_2025_retake_grade_determinator_node
