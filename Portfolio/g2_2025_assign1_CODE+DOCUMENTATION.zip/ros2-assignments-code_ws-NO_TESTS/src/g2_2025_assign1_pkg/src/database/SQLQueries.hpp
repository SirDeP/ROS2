/* SQLQueries.hpp
 * SQL query definitions for the exam result generator
 *
 * Reviewed by: <x>
 * Changelog:
 * [23-09-2025] Wessel T: Created initial database state
 */
#pragma once

static const std::string SQL_CREATE_ENROLLMENTS_TABLE = R"(
    CREATE TABLE IF NOT EXISTS student_enrollments (
        id SERIAL PRIMARY KEY,
        student_name VARCHAR(100) NOT NULL,
        course_name VARCHAR(100) NOT NULL,
        enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(student_name, course_name)
    );
)";

static const std::string SQL_CREATE_EXAM_RESULTS = R"(
    CREATE TABLE IF NOT EXISTS exam_results (
        id SERIAL PRIMARY KEY,
        student_name VARCHAR(100) NOT NULL,
        course_name VARCHAR(100) NOT NULL,
        exam_grade INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
)";
// UNIQUE(student_name, course_name)

static const std::string SQL_CREATE_COURSE_RESULTS = R"(
    CREATE TABLE IF NOT EXISTS final_course_results (
        id SERIAL PRIMARY KEY,
        student_name VARCHAR(100) NOT NULL,
        course_name VARCHAR(100) NOT NULL,
        exam_count INTEGER NOT NULL,
        final_grade INTEGER NOT NULL,
        is_retake BOOLEAN DEFAULT FALSE,
        retake_done BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
)";
// UNIQUE(student_name, course_name)

static const std::string SQL_SELECT_EXAM_RESULTS_COUNT = R"(
    SELECT COUNT(*) FROM exam_results
)";

static const std::string SQL_SELECT_MISSING_RESULTS = R"(
    SELECT se.student_name, se.course_name
    FROM student_enrollments se
    LEFT JOIN final_course_results fcr
        ON se.student_name = fcr.student_name
        AND se.course_name = fcr.course_name
    WHERE fcr.id IS NULL
)";

static const std::string SQL_SELECT_STUDENT_EXAM_RESULTS = R"(
    SELECT COUNT(*), AVG(exam_grade)
    FROM exam_results
    WHERE student_name = $1 AND course_name = $2
)";


static const std::string SQL_SELECT_FAILED_COURSE_RESULTS = R"(
    SELECT fcr.student_name, fcr.course_name, fcr.final_grade, fcr.exam_count
    FROM final_course_results fcr
    WHERE fcr.final_grade < 55 AND fcr.retake_done = FALSE
)";

static const std::string SQL_INSERT_EXAM_RESULT = R"(
    INSERT INTO exam_results (student_name, course_name, exam_grade)
    VALUES ($1, $2, $3)
)";
// ON CONFLICT (student_name, course_name)
// DO UPDATE SET exam_grade = EXCLUDED.exam_grade, created_at = CURRENT_TIMESTAMP

static const std::string SQL_INSERT_STUDENT_ENROLLMENT = R"(
    INSERT INTO student_enrollments (student_name, course_name)
    VALUES ($1, $2)
    ON CONFLICT DO NOTHING
)";

static const std::string SQL_DELETE_STUDENT_ENROLLMENT = R"(
    DELETE FROM student_enrollments
    WHERE student_name = $1 AND course_name = $2
)";

static const std::string SQL_SELECT_STUDENT_LIST = R"(
    SELECT COUNT(*) FROM student_enrollments
)";

static const std::string SQL_UPDATE_RETAKE_STATUS = R"(
    UPDATE final_course_results
    SET retake_done = TRUE
    WHERE student_name = $1 AND course_name = $2 AND retake_done = FALSE
)";

static const std::string SQL_INSERT_FINAL_COURSE_RESULT = R"(
    INSERT INTO final_course_results (student_name, course_name, exam_count, final_grade, is_retake)
    VALUES ($1, $2, $3, $4, $5)
)";
// ON CONFLICT (student_name, course_name)
// DO UPDATE SET exam_count = EXCLUDED.exam_count, final_grade = EXCLUDED.final_grade, created_at = CURRENT_TIMESTAMP
