/* DatabaseManager.hpp
 * Database manager for the exam result generator
 *
 * Reviewed by: <x>
 * Changelog:
 * [23-09-2025] Wessel T: Created database manager class for all DB operations
 */
#pragma once

#include <memory>
#include <vector>
#include <string>
#include <pqxx/pqxx>
#include "rclcpp/rclcpp.hpp"

#include "StudentCourse.hpp"
#include "config/ConfigManager.hpp"

namespace assignments::one {

class DatabaseManager {
public:
    explicit DatabaseManager(rclcpp::Logger logger);
    ~DatabaseManager() = default;

    bool connect(const std::string& connection_string);
    virtual bool is_connected() const;

    // Table operations
    virtual void init_database();
    void create_tables();
    void insert_sample_data();

    // Data operations
    std::vector<StudentCourse> queue_pending_combinations();
    bool store_exam_result(const std::string& student_name, const std::string& course_name, int grade);
    bool enroll_student_into_course(const StudentCourse& sc);
    bool remove_student_from_course(const StudentCourse& sc);
    virtual bool store_final_course_result(
        const StudentCourse& sc,
        int exam_count,
        int final_grade,
        bool is_retake
    );

    int get_final_course_grade(const StudentCourse& sc);
    std::vector<StudentCourse> get_failed_course_results();
    bool update_retake_status(const StudentCourse &sc);

private:
    rclcpp::Logger logger_;

    std::unique_ptr<pqxx::connection> conn_;
    std::unique_ptr<ConfigManager> config_manager_;

    std::vector<std::pair<std::string, std::string>> sample_students_data_ = {
        {"Wessel", "ROS2"},
        {"Vincent", "ROS2"},
        {"Mohammed", "Differentieren"},
        {"Tilmann", "Differentieren"},
    };
};

} // namespace assignments::one
