/* StudentCourse.hpp
 * Data structure for student-course combinations
 *
 * Reviewed by: <x>
 * Changelog:
 * [23-09-2025] Wessel T: Created initial structure
 */
#pragma once

#include <string>

namespace assignments::one {

struct StudentCourse {
    std::string student_name;
    std::string course_name;

    bool operator==(const StudentCourse& other) const {
        return student_name == other.student_name && course_name == other.course_name;
    }

    bool operator<(const StudentCourse& other) const {
        return student_name < other.student_name
            || (student_name == other.student_name
                && course_name < other.course_name);
    }

    bool operator!=(const StudentCourse& other) const {
        return !(*this == other);
    }
};

typedef std::map<StudentCourse, std::vector<int>> StudentCourseResultMap;

} // namespace assignments::one
