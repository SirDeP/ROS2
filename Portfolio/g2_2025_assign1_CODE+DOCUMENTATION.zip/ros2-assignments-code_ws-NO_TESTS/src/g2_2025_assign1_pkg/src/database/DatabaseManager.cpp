#include "DatabaseManager.hpp"

#include <pqxx/pqxx>
#include "rclcpp/rclcpp.hpp"

#include "SQLQueries.hpp"
#include "config/ConfigManager.hpp"

namespace assignments::one {

DatabaseManager::DatabaseManager(rclcpp::Logger logger) : logger_(logger) {
    config_manager_ = std::make_unique<ConfigManager>(logger_);
    init_database();
}

bool DatabaseManager::is_connected() const {
    return conn_ && conn_->is_open();
}

bool DatabaseManager::connect(const std::string& connection_string) {
    try {
        RCLCPP_INFO(logger_, "[DBS] connecting to PostgreSQL database...");

        conn_ = std::make_unique<pqxx::connection>(connection_string);

        if (conn_->is_open()) {
            RCLCPP_INFO(logger_, "[DBS] successfully connected to database (%s)", conn_->dbname());
            return true;
        } else {
            RCLCPP_ERROR(logger_, "[DBS] failed to open database connection");
            return false;
        }

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] sql error: %s", e.what());
        return false;
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] connection error: %s", e.what());
        return false;
    }
}

void DatabaseManager::init_database() {
    if (!config_manager_ || !config_manager_->is_loaded()) {
        RCLCPP_ERROR(logger_, "[DBS] configuration not loaded, cannot initialize database");
        return;
    }

    auto db_config = config_manager_->get_database_config();
    if (!db_config.has_value()) {
        RCLCPP_ERROR(logger_, "[DBS] failed to get database configuration");
        return;
    }

    std::string connection_string = db_config->to_connection_string();

    if (connect(connection_string)) {
        create_tables();
        insert_sample_data();
    }
}

std::vector<StudentCourse> DatabaseManager::queue_pending_combinations() {
    std::vector<StudentCourse> combinations;

    if (!is_connected()) {
        return combinations;
    }

    try {
        pqxx::work txn(*conn_);

        auto result = txn.exec(SQL_SELECT_MISSING_RESULTS);

        for (const auto& row : result) {
            StudentCourse sc;
            sc.student_name = row[0].as<std::string>();
            sc.course_name = row[1].as<std::string>();
            combinations.push_back(sc);
        }

        RCLCPP_INFO(logger_, "[DBS] queued %zu pending combinations", combinations.size());

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] queueing combinations failed: %s", e.what());
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] database error: %s", e.what());
    }

    return combinations;
}

bool DatabaseManager::enroll_student_into_course(const StudentCourse& sc) {
    if (!is_connected()) {
        return false;
    }

    try {
        pqxx::work txn(*conn_);

        txn.exec_params(SQL_INSERT_STUDENT_ENROLLMENT, sc.student_name, sc.course_name);

        txn.commit();
        return true;

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] enroll student into course failed: %s", e.what());
        return false;
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] database error: %s", e.what());
        return false;
    }
}

bool DatabaseManager::remove_student_from_course(const StudentCourse& sc) {
    if (!is_connected()) {
        return false;
    }

    try {
        pqxx::work txn(*conn_);

        txn.exec_params(SQL_DELETE_STUDENT_ENROLLMENT, sc.student_name, sc.course_name);

        txn.commit();
        return true;

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] unenroll student from course failed: %s", e.what());
        return false;
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] database error: %s", e.what());
        return false;
    }
}

bool DatabaseManager::store_exam_result(const std::string& student_name, const std::string& course_name, int grade) {
    if (!is_connected()) return false;

    try {
        pqxx::work txn(*conn_);

        txn.exec_params(
            SQL_INSERT_EXAM_RESULT,
            student_name, course_name, grade
        );

        txn.commit();
        return true;

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] store result failed: %s", e.what());
        return false;
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] database error: %s", e.what());
        return false;
    }
}

bool DatabaseManager::store_final_course_result(
    const StudentCourse& sc,
    int exam_count,
    int final_grade,
    bool is_retake
) {
    if (!is_connected()) return false;

    try {
        pqxx::work txn(*conn_);

        txn.exec_params(
            SQL_INSERT_FINAL_COURSE_RESULT,
            sc.student_name, sc.course_name, exam_count, final_grade, is_retake
        );

        txn.commit();
        return true;

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] store final course result failed: %s", e.what());
        return false;
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] database error: %s", e.what());
        return false;
    }
}

void DatabaseManager::create_tables() {
    if (!conn_ || !conn_->is_open()) return;

    try {
        pqxx::work txn(*conn_);

        txn.exec(SQL_CREATE_ENROLLMENTS_TABLE);
        txn.exec(SQL_CREATE_EXAM_RESULTS);
        txn.exec(SQL_CREATE_COURSE_RESULTS);

        txn.commit();

        RCLCPP_INFO(logger_, "[DBS] database tables ready");

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] CREATE TABLE failed: %s", e.what());
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] database error: %s", e.what());
    }
}

void DatabaseManager::insert_sample_data() {
    if (!is_connected()) {
        return;
    }

    try {
        pqxx::work txn(*conn_);

        auto student_result = txn.exec(SQL_SELECT_STUDENT_LIST);
        int student_count = student_result[0][0].as<int>();

        auto grades_result = txn.exec(SQL_SELECT_EXAM_RESULTS_COUNT);
        int grades_count = grades_result[0][0].as<int>();

        if (student_count == 0 && grades_count == 0) {
            for (const auto& [student, course] : sample_students_data_) {
                txn.exec_params(SQL_INSERT_STUDENT_ENROLLMENT, student, course);
            }

            txn.commit();
            RCLCPP_INFO(logger_, "[DBS] inserted sample student enrollment data");
        }

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] insert sample data failed: %s", e.what());
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] database error: %s", e.what());
    }
}

int DatabaseManager::get_final_course_grade(const StudentCourse& sc) {
    if (!is_connected()) return -1;

    try {
        pqxx::work txn(*conn_);

        auto result = txn.exec_params(SQL_SELECT_STUDENT_EXAM_RESULTS, sc.student_name, sc.course_name);

        if (result.size() == 1) {
            int exam_count = result[0][0].as<int>();
            if (exam_count == 0) {
                return -1; // No exams taken
            }
            int avg_grade = static_cast<int>(result[0][1].as<double>() + 0.5);
            return avg_grade;
        } else {
            return -1; // No results found
        }

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] get final course grade failed: %s", e.what());
        return -1;
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] database error: %s", e.what());
        return -1;
    }
}

std::vector<StudentCourse> DatabaseManager::get_failed_course_results() {
    std::vector<StudentCourse> failed_courses;

    if (!is_connected()) {
        return failed_courses;
    }

    try {
        pqxx::work txn(*conn_);

        auto result = txn.exec(SQL_SELECT_FAILED_COURSE_RESULTS);

        for (const auto& row : result) {
            StudentCourse sc;
            sc.student_name = row[0].as<std::string>();
            sc.course_name = row[1].as<std::string>();

            failed_courses.push_back(sc);
        }

        RCLCPP_INFO(logger_, "[DBS] found %zu failed course results", failed_courses.size());

    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] 'get failed course results' failed: %s", e.what());
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] database error: %s", e.what());
    }

    return failed_courses;
}

bool DatabaseManager::update_retake_status(const StudentCourse& sc) {
    if (!is_connected()) {
        return false;
    }

    try {
        pqxx::work txn(*conn_);
        txn.exec_params(SQL_UPDATE_RETAKE_STATUS, sc.student_name, sc.course_name);
        txn.commit();
        return true;
    } catch (const pqxx::sql_error &e) {
        RCLCPP_ERROR(logger_, "[DBS] 'update retake status' failed: %s", e.what());
        return false;
    } catch (const std::exception &e) {
        RCLCPP_ERROR(logger_, "[DBS] database error: %s", e.what());
        return false;
    }
}

} // namespace assignments::one
