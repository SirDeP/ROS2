#pragma once

#include <memory>
#include <string>
#include <random>
#include <vector>
#include <chrono>

#include "rclcpp/rclcpp.hpp"
#include "g2_2025_assign1_interfaces_pkg/msg/exam.hpp"
#include "g2_2025_assign1_interfaces_pkg/msg/student.hpp"
#include "g2_2025_assign1_interfaces_pkg/srv/exams.hpp"

#include "database/DatabaseManager.hpp"
#include "database/StudentCourse.hpp"

namespace assignments::one::g2_2025_final_grade_determinator_node {

class FinalGradeDeterminator : public rclcpp::Node {
public:
    FinalGradeDeterminator(std::unique_ptr<DatabaseManager> db_manager = nullptr);
private:
    rclcpp::Subscription<g2_2025_assign1_interfaces_pkg::msg::Exam>::SharedPtr exam_subscriber_;
    rclcpp::Publisher<g2_2025_assign1_interfaces_pkg::msg::Student>::SharedPtr student_publisher_;

    rclcpp::Client<g2_2025_assign1_interfaces_pkg::srv::Exams>::SharedPtr exam_service_client_;

    std::unique_ptr<DatabaseManager> db_manager_;

    StudentCourse student_course_combo_;
    StudentCourseResultMap data_map_;

    // Params
    int grade_collection_amount_;

    void grade_calculator_request(StudentCourse combo);
    void exam_results_callback(const g2_2025_assign1_interfaces_pkg::msg::Exam::SharedPtr msg);
    void grade_calculator_response(
        rclcpp::Client<g2_2025_assign1_interfaces_pkg::srv::Exams>::SharedFuture future,
        StudentCourse studentCourseCombo
    );
};

} // namespace assignments::one::g2_2025_final_grade_determinator_node
