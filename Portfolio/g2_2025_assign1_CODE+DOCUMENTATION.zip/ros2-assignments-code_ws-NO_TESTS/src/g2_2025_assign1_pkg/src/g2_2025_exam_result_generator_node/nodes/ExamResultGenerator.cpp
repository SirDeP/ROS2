#include "ExamResultGenerator.hpp"

namespace assignments::one::g2_2025_exam_result_generator_node {

ExamResultGenerator::ExamResultGenerator()
    : Node("g2_2025_exam_result_generator_node"),
    gen_(rd_()),
    grade_dist_(10, 100)
{
    this->declare_parameter("delay_between_grades_ms", 2000);
    int delay_ms = this->get_parameter("delay_between_grades_ms").as_int();
    delay_between_grades_ = std::chrono::milliseconds(delay_ms);

    db_manager_ = std::make_unique<DatabaseManager>(this->get_logger());

    // Load initial student/course combinations from database
    queue_pending_combinations();

    // Create publisher for exam results
    exam_publisher_ = this->create_publisher<g2_2025_assign1_interfaces_pkg::msg::Exam>("exam_results", 10);

    // Create subscriber for adding/removing student/course combinations
    student_subscriber_ = this->create_subscription<g2_2025_assign1_interfaces_pkg::msg::Student>(
        "student_course_management", 10,
        std::bind(
            &ExamResultGenerator::student_management_callback,
            this,
            std::placeholders::_1
        )
    );

    // Create timer to generate random exam results every 2 seconds
    timer_ = this->create_wall_timer(
        delay_between_grades_,
        std::bind(&ExamResultGenerator::generate_random_result, this)
    );

    RCLCPP_INFO(this->get_logger(),
        "g2_2025_exam_result_generator_node started, %zu pending operations",
        operations_queue_.size()
    );
}

void ExamResultGenerator::queue_pending_combinations() {
    if (!db_manager_ || !db_manager_->is_connected()) return;

    operations_queue_ = db_manager_->queue_pending_combinations();
}

void ExamResultGenerator::generate_random_result() {
    if (operations_queue_.empty()) {
        RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 10000, "queue is empty");
        return;
    }

    if (!db_manager_ || !db_manager_->is_connected()) {
        RCLCPP_WARN(this->get_logger(), "no database connection");
        return;
    }

    // Select random student/course combination
    std::uniform_int_distribution<> index_dist(0, operations_queue_.size() - 1);
    int random_index = index_dist(gen_);
    auto selected = operations_queue_[random_index];

    int grade = grade_dist_(gen_);

    db_manager_->store_exam_result(selected.student_name, selected.course_name, grade);

    // Publish exam result
    auto exam_msg = g2_2025_assign1_interfaces_pkg::msg::Exam();
    exam_msg.student_name = selected.student_name;
    exam_msg.course_name = selected.course_name;
    exam_msg.result = grade;
    exam_msg.timestamp = this->get_clock()->now();

    exam_publisher_->publish(exam_msg);

    RCLCPP_INFO(this->get_logger(),
        "generated grade: (%d) %s in %s",
        grade, selected.student_name.c_str(), selected.course_name.c_str()
    );
}

void ExamResultGenerator::student_management_callback(const g2_2025_assign1_interfaces_pkg::msg::Student::SharedPtr msg) {
    StudentCourse sc;
    sc.student_name = msg->student_name;
    sc.course_name = msg->course_name;

    auto it = std::find(operations_queue_.begin(), operations_queue_.end(), sc);

    if (it != operations_queue_.end()) {
        operations_queue_.erase(it);
        db_manager_->remove_student_from_course(sc);
        RCLCPP_INFO(this->get_logger(), "removed from queue: %s - %s",
            sc.student_name.c_str(), sc.course_name.c_str()
        );
    } else {
        add_student_course_combination(sc);
        RCLCPP_INFO(this->get_logger(), "added to queue: %s - %s",
            sc.student_name.c_str(), sc.course_name.c_str()
        );
    }
}

void ExamResultGenerator::add_student_course_combination(const StudentCourse& sc) {
    if (!db_manager_ || !db_manager_->is_connected()) {
        return;
    }

    if (db_manager_->enroll_student_into_course(sc)) {
        auto it = std::find(operations_queue_.begin(), operations_queue_.end(), sc);
        if (it == operations_queue_.end()) {
            operations_queue_.push_back(sc);
        }
    }
}

} // namespace assignments::one::g2_2025_exam_result_generator_node
