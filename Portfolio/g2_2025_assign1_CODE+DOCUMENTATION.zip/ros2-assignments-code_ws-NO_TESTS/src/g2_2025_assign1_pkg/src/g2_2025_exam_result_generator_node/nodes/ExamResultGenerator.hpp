/* nodes/ExamResultGenerator.hpp
 * Exam result generator node for the first assignment of the course EE at InHolland.
 *
 * Collects student/course combinations from database where exam results need to be generated.
 * Randomly generates and broadcasts exam marks (10-100) every 2 seconds.
 * Can receive messages to add/remove student/course combinations.
 *
 * Reviewed by: <x>
 * Changelog:
 * [23-09-2025] Wessel T: Initial Implementation
 * [05-10-2025] Wessel T: Added delay between grades parameter
 */
#pragma once

#include <memory>
#include <string>
#include <random>
#include <vector>
#include <chrono>

#include "rclcpp/rclcpp.hpp"
#include "g2_2025_assign1_interfaces_pkg/msg/exam.hpp"
#include "g2_2025_assign1_interfaces_pkg/msg/student.hpp"

#include "database/DatabaseManager.hpp"
#include "database/StudentCourse.hpp"

namespace assignments::one::g2_2025_exam_result_generator_node {

class ExamResultGenerator : public rclcpp::Node {
public:
    ExamResultGenerator();

private:
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<g2_2025_assign1_interfaces_pkg::msg::Exam>::SharedPtr exam_publisher_;
    rclcpp::Subscription<g2_2025_assign1_interfaces_pkg::msg::Student>::SharedPtr student_subscriber_;

    std::unique_ptr<DatabaseManager> db_manager_;

    std::random_device rd_;
    std::mt19937 gen_;
    std::uniform_int_distribution<> grade_dist_;

    std::vector<StudentCourse> operations_queue_;

    std::chrono::milliseconds delay_between_grades_ { 2000 };

    void queue_pending_combinations();
    void generate_random_result();
    void student_management_callback(const g2_2025_assign1_interfaces_pkg::msg::Student::SharedPtr msg);
    void add_student_course_combination(const StudentCourse& sc);
};

} // namespace assignments::one::g2_2025_exam_result_generator_node
