#pragma once

#include <memory>
#include <string>
#include <random>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "g2_2025_assign1_interfaces_pkg/msg/exam.hpp"
#include "g2_2025_assign1_interfaces_pkg/msg/student.hpp"
#include "g2_2025_assign1_interfaces_pkg/srv/exams.hpp"


namespace assignments::one::g2_2025_grade_calculator_node {

class GradeCalculator : public rclcpp::Node {
public:
    GradeCalculator();
private:
    rclcpp::Service<g2_2025_assign1_interfaces_pkg::srv::Exams>::SharedPtr grade_calculator_service_server_;

    int grades_total_;
    int grade_result_ = 0;

    void grade_calculator_callback(
        const g2_2025_assign1_interfaces_pkg::srv::Exams::Request::SharedPtr request,
        const g2_2025_assign1_interfaces_pkg::srv::Exams::Response::SharedPtr response
    );
};

}
