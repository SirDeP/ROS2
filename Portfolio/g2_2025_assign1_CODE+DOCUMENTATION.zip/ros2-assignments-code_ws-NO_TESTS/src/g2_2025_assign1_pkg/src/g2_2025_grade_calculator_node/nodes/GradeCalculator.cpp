#include "GradeCalculator.hpp"

namespace assignments::one::g2_2025_grade_calculator_node {

GradeCalculator::GradeCalculator() : Node("g2_2025_grade_calculator_node") {
    grade_calculator_service_server_ = this->create_service<g2_2025_assign1_interfaces_pkg::srv::Exams>(
        "grade_calculator_service",
        std::bind(
            &GradeCalculator::grade_calculator_callback,
            this,
            std::placeholders::_1,
            std::placeholders::_2
        )
    );

    RCLCPP_INFO(this->get_logger(), "Grade calculator service server started");
}

void GradeCalculator::grade_calculator_callback(
    const g2_2025_assign1_interfaces_pkg::srv::Exams::Request::SharedPtr request,
    const g2_2025_assign1_interfaces_pkg::srv::Exams::Response::SharedPtr response
) {
    if (request->exam_grades.size() != 0){
        grades_total_ = std::accumulate(request->exam_grades.begin(), request->exam_grades.end(), 0);

        auto lowercase = request->student_name;

        std::transform(lowercase.begin(), lowercase.end(), lowercase.begin(), ::tolower);

        grade_result_ = (grades_total_) / request->exam_grades.size();

        if (lowercase.compare("wessel") == 0){
            grade_result_ += 10;
        }

        if (grade_result_ > 100) {
            grade_result_ = 100;
        } else if (grade_result_ < 10){
            grade_result_ = 10;
        }
    }

    response->result = grade_result_;
}

} // namespace assignments::one::g2_2025_grade_calculator_node


